#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 22:44:34 2019

@author: mashagubenko
"""

# Import libraries
import pandas as pd
import csv
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns

from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold

import sklearn
from sklearn.preprocessing import normalize
import plotly.graph_objects as go
import chart_studio.plotly as py


def Main():
    dfnew = MasterDataSet() #create master dataset 
    df3 = UrbData(dfnew) #create a subset of the data to be used for the urban land analysis
    #Most Important Attributed Analysis
    LR(dfnew) #run linear regression analysis
    GC(dfnew) #run granger causality analysis
    RF(dfnew)
    
    #Regional Analysis
    RegionAnalysis(dfnew)
    
    #Urban Land Analysis
    TTest(df3,'MaxT') #run ttest on max temperatures
    TTest(df3,'MinT') #run ttest on max temperatures
    LR2(df3,'MaxT') #run linear regression analysis on the subset of the data and MaxT
    LR2(df3,'MinT') #run linear regression analysis on the subset of the data and MinT

######### DATA PREPROCESSING ######################

# This function creates a master dataset of all our data 
def MasterDataSet():    
    new = PopSet() #calling a function to create a dataframe of population data
    dfnew = TransitSet(new) #calling a function to add transit data
    dfnew = VehRegSet(dfnew) #calling a function to add veh reg data    
    dfnew = ElecSet(dfnew)  #calling a function to add electric vehicle data
    dfnew = AirportSet(dfnew)  #calling a function to add airport data
    dfnew = RegSet(dfnew)  #calling a function to add regions data
    dfnew = UrbSet(dfnew)  #calling a function to add urban land data
    dfnew = AltFuelSet(dfnew) #calling a function to alt facilities data
    dfnew = FacSet(dfnew) #calling a function to factories data
    dfnew = TempSet(dfnew)  #calling a function to add temperature data
    dfnew = ForestSet(dfnew)  #calling a function to add forest data
    dfnew = MaxMinTinc(dfnew)  #calling a function to create temp difference 
    
    dfnew['CarPC'] = dfnew['Automobiles']/dfnew.Population #creating a car per capita variable
    dfnew['TruckPC'] = dfnew['Trucks']/dfnew.Population #creating a truck per capita variable
    dfnew['BusPC'] = dfnew['Buses']/dfnew.Population  #creating a bus per capita variable
    dfnew['MCPC'] = dfnew['Motorcycles']/dfnew.Population #creating a motorcycle per capita variable
    dfnew['LAPC'] = dfnew['Large Airport']/dfnew.Population #creating a large airport per capita variable
    dfnew['MAPC'] = dfnew['Medium Airport']/dfnew.Population #creating a med airport per capita variable
    dfnew['SAPC'] = dfnew['Small Airport']/dfnew.Population #creating a small airport per capita variable
    
    dfnew.to_csv('yummy2.csv')
    return(dfnew) #return the final dataframe

#Functino to read in popuation data
def PopSet():
    # Start the master data set by setting a dataframe of all states' 
    # populations by year 
    # Import the population info by State
    popstate = pd.read_csv('Population_by_State_by_Year_2000_2010.csv')
    popstate = popstate.drop(columns=['Unnamed: 0','census2010pop','estimatesbase2000'])
    colpop = popstate.columns
    
    new = pd.DataFrame(columns=['Name', 'Population', 'Year'])
    # Loop through every column and add it as time series information for each state
    for col in colpop[1:len(colpop)]:
        df = popstate[['name',col]]
        df = df.groupby('name',as_index=False).max()
        df = df.rename(columns={col: 'Population', 'name':'Name'})
        df['Year'] = int(col[len(col)-4:len(col)])
        new = pd.concat([new,df],ignore_index=True) #combine the dataframes into one of all years
        
    # Import the population info by State part 2
    popstate = pd.read_csv('nst-est2018-alldata.csv')
    # Loop through every column and add it as time series information for each state
    popstate = popstate[['NAME', 'POPESTIMATE2011',
           'POPESTIMATE2012', 'POPESTIMATE2013', 'POPESTIMATE2014',
           'POPESTIMATE2015', 'POPESTIMATE2016', 'POPESTIMATE2017',
           'POPESTIMATE2018']]
    popstate = popstate.drop(popstate.index[[0,1,2,3,4]])
    colpop = popstate.columns
    
    new2 = pd.DataFrame(columns=['Name', 'Population', 'Year'])
    for col in colpop[1:len(colpop)]:
        df = popstate[['NAME',col]]
        df = df.groupby('NAME',as_index=False).max()
        df = df.rename(columns={col: 'Population', 'NAME':'Name'})
        df['Year'] = int(col[len(col)-4:len(col)])
        new2 = pd.concat([new2,df],ignore_index=True) #combine the dataframes into one of all years
    
    # Combine the two parts of population datasets into one
    new = pd.concat([new,new2],ignore_index=True)    
    
    return(new)

#Function to read in transit data
def TransitSet(new):
    # List of all states to change abbreviations to full names
    states = {
            'AK': 'Alaska',
            'AL': 'Alabama',
            'AR': 'Arkansas',
            'AS': 'American Samoa',
            'AZ': 'Arizona',
            'CA': 'California',
            'CO': 'Colorado',
            'CT': 'Connecticut',
            'DC': 'District of Columbia',
            'DE': 'Delaware',
            'FL': 'Florida',
            'GA': 'Georgia',
            'GU': 'Guam',
            'HI': 'Hawaii',
            'IA': 'Iowa',
            'ID': 'Idaho',
            'IL': 'Illinois',
            'IN': 'Indiana',
            'KS': 'Kansas',
            'KY': 'Kentucky',
            'LA': 'Louisiana',
            'MA': 'Massachusetts',
            'MD': 'Maryland',
            'ME': 'Maine',
            'MI': 'Michigan',
            'MN': 'Minnesota',
            'MO': 'Missouri',
            'MP': 'Northern Mariana Islands',
            'MS': 'Mississippi',
            'MT': 'Montana',
            'NA': 'National',
            'NC': 'North Carolina',
            'ND': 'North Dakota',
            'NE': 'Nebraska',
            'NH': 'New Hampshire',
            'NJ': 'New Jersey',
            'NM': 'New Mexico',
            'NV': 'Nevada',
            'NY': 'New York',
            'OH': 'Ohio',
            'OK': 'Oklahoma',
            'OR': 'Oregon',
            'PA': 'Pennsylvania',
            'PR': 'Puerto Rico',
            'RI': 'Rhode Island',
            'SC': 'South Carolina',
            'SD': 'South Dakota',
            'TN': 'Tennessee',
            'TX': 'Texas',
            'UT': 'Utah',
            'VA': 'Virginia',
            'VI': 'Virgin Islands',
            'VT': 'Vermont',
            'WA': 'Washington',
            'WI': 'Wisconsin',
            'WV': 'West Virginia',
            'WY': 'Wyoming'
    }
    
    
    # Import the transit data
    # Annual
    # Years 2002 - 2017 (most data for 2017)
    # Location as Lat/Long and City Name
    # Add to the master data set each piece of info from the transit data set by state by year 
    transit = pd.read_csv('TransitwithLatLong.csv')
    stat = transit['HQ State'].apply(lambda x: states[x]) #create a list of all states
    transit['HQ State'] = stat #add a column of all states
    #Total trips by state by year
    a = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Unlinked Passenger Trips FY'].sum()
    a = a.rename(columns={'FY End Year': 'Year', 'HQ State':'Name', 'Unlinked Passenger Trips FY': 'Passenger Trips'})
    #Largest service area by state by year
    b = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Service Area SQ Miles'].max()
    b = b.rename(columns={'FY End Year': 'Year', 'HQ State':'Name', 'Service Area SQ Miles': 'Largest Transit Service Area'})
    #Total trips by state by year
    c = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Operating Expenses FY'].sum()
    c = c.rename(columns={'FY End Year': 'Year', 'HQ State':'Name'})
    
    # Add transit info to the master dataframe by state and year
    dfnew = pd.merge(new, a, how='left', on=['Name', 'Year'])
    dfnew = pd.merge(dfnew, b, how='left', on=['Name', 'Year'])
    dfnew = pd.merge(dfnew, c, how='left', on=['Name', 'Year'])
    
    return(dfnew)

#Function to add vehicle reg data    
def VehRegSet(dfnew):
    # Import the vehicle registration data
    # Annual by State
    # Location as state
    # Years 1995 - 2014
    # Add the data to the master dataset by state by year 
    vehreg = pd.read_csv('Vehicle_Registration_By_State_By_Year.csv')
    vehreg = vehreg.drop(columns=['Unnamed: 0', 'index'])
    vehreg = vehreg.rename(columns = {'State': 'Name', 'Motorcicles': 'Motorcycles'})
    # Conform state names
    vehreg.Name = vehreg.Name.str.replace(r'[\(\)\d]+', '')
    vehreg.Name = vehreg.Name.str.replace('/','')
    vehreg = vehreg.replace('Dist. of Col.', 'District of Columbia')
    
    # Clean the state names information for state names neding in ' ' or '  '
    for k in vehreg.Name:
        if k[len(k)-1] == ' ':
            if k[len(k)-2] == ' ':
                vehreg = vehreg.replace(k, k[0:len(k)-2])
            else:
                vehreg = vehreg.replace(k, k[0:len(k)-1])
    
    # Correct for extra spaces in state name 
    vehreg['Name'][693] = vehreg['Name'][642]
    # Add to the master dataframe by state and year
    dfnew = pd.merge(dfnew, vehreg, how='left', on=['Name', 'Year'])
    # Divide by 10,000 for scaling purposes for linear regression
    for col in ['Automobiles', 'Buses', 'Trucks','Motorcycles']:
        dfnew[col] = dfnew[col]/10000
    
    return(dfnew)
    

#Functino to add electric vehicle data
def ElecSet(dfnew):
    # Import the data set on electric vehicle registrations 
    # Annual 
    # Aggregated for the entire country by vehicle type & year so location is US
    # Years: 1999-2017
    evreg = pd.read_csv('EV_Registrations_by_Type_US_by_Year.csv')
    evreg = evreg.drop(columns=['Unnamed: 0','Unnamed: 0.1'])
    evreg = evreg.replace('U',0) #replace empty values with 0s 
    colev = evreg.columns
    
    # Add the ev registration data to the master dataset
    # Total number of ev registrations in the US is added to each state for each type of ev
    dfnew['Hybrid'] = 0 
    dfnew['PlugHybrid'] = 0 
    dfnew['Electric'] = 0 
    # Add a column of total values by state by year 
    for col in colev:
        dfnew['Hybrid'].mask(dfnew['Year']== int(col), evreg[col][0], inplace=True)
        dfnew['PlugHybrid'].mask(dfnew['Year']== int(col), evreg[col][1], inplace=True)
        dfnew['Electric'].mask(dfnew['Year']== int(col), evreg[col][2], inplace=True)
    
    # Estimate state level values by dividing the country totals by population 
    dfnew['Hybrid'] = pd.to_numeric(dfnew['Hybrid'])
    dfnew['PlugHybrid'] = pd.to_numeric(dfnew['PlugHybrid'])
    dfnew['Electric'] = pd.to_numeric(dfnew['Electric'])
    dfnew['Hybrid'] = dfnew['Hybrid']/dfnew['Population']
    dfnew['PlugHybrid'] = dfnew['PlugHybrid']/dfnew['Population']
    dfnew['Electric'] = dfnew['Electric']/dfnew['Population']
    return(dfnew)

#Function to add airport data    
def AirportSet(dfnew):
    # Import the data on airport location
    # Add number of airports by type by state to the master dataset
    airloc = pd.read_csv('AirportLocation.csv') 
    # Conform state names
    airloc['Location'] = airloc['Location'].str.lower()
    airloc['Location'] = airloc['Location'].str.title()
    airloc = airloc.replace('District Of Columbia', 'District of Columbia')
    airloc = airloc[airloc['type'] != 'closed'] #drop the rows where airports have been closed
    airloc = airloc.rename(columns={'Location': 'Name'})
    
    # Split into dataframes for each airport type
    a1 = airloc[airloc['type'] == 'balloonport']
    a2 = airloc[airloc['type'] == 'heliport']
    a3 = airloc[airloc['type'] == 'large_airport']
    a4 = airloc[airloc['type'] == 'medium_airport']
    a5 = airloc[airloc['type'] == 'seaplane_base']
    a6 = airloc[airloc['type'] == 'small_airport']
    
    # Aggregate the totals of each type of airprot by state by year 
    # And merge with the master data frame
    a11 = a1.groupby(['Name'], as_index = False).size().to_frame('Balloonport')
    dfnew = pd.merge(dfnew, a11, how='left', on=['Name'])
    a21 = a2.groupby(['Name'], as_index = False).size().to_frame('Heliport')
    dfnew = pd.merge(dfnew, a21, how='left', on=['Name'])
    a31 = a3.groupby(['Name'], as_index = False).size().to_frame('Large Airport')
    dfnew = pd.merge(dfnew, a31, how='left', on=['Name'])
    a41 = a4.groupby(['Name'], as_index = False).size().to_frame('Medium Airport')
    dfnew = pd.merge(dfnew, a41, how='left', on=['Name'])
    a51 = a5.groupby(['Name'], as_index = False).size().to_frame('Seaplane Base')
    dfnew = pd.merge(dfnew, a51, how='left', on=['Name'])
    a61 = a6.groupby(['Name'], as_index = False).size().to_frame('Small Airport')
    dfnew = pd.merge(dfnew, a61, how='left', on=['Name'])
    return(dfnew)

#Functino to add region data
def RegSet(dfnew):
    # Set up lists of states belonging to each region
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']
    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']
    
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']
    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']
    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']
    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']
    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    # Set up columns corresponding to each of the region in the master dataset
    reg = ['NE','SE','PS','NC','SC','RM','GP','PN']
    for lst in reg:
        dfnew[lst] = 0
    
    # Loop through the lists of regions and identify states that belong to 
    # each region by assigning 1 to that column    
    reglist = [NE,SE,PS,NC,SC,RM,GP,PN]       
    i = 0 
    while i < len(reglist):  
        #print(reg[i])
        for j in range(0,len(dfnew['Name'])):
            if dfnew['Name'][j] in reglist[i]:
                dfnew[reg[i]][j] = 1
        i += 1
    return(dfnew)

#Function to add Urban Land data
def UrbSet(dfnew):
    # Set up lists of states belonging to each region
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']
    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']
    
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']
    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']
    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']
    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']
    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    # Set up columns corresponding to each of the region in the master dataset
    reg = ['NE','SE','PS','NC','SC','RM','GP','PN']
    # Import the urban land data set
    urbland = pd.read_csv('Urban_Land(2000-2010).csv') 
    urbland = urbland.drop(urbland.index[[0,9]]) # Drop totals
    
    # Pull the data from the urban data set on growth % of urban land by each region
    # Add the total % increase to each state belonging to the region in the master dataset    
    dfnew['Percent increase in urban land 2000-2010'] = 0
    for i in range(0, len(reg)-1):
        dfnew['Percent increase in urban land 2000-2010'].mask(dfnew[reg[i]] == 1, urbland['Percent increase in urban land 2000-2010'][i+1] , inplace=True)
    return(dfnew)

#Function to add alt fuel data
def AltFuelSet(dfnew):
    # Import the data set on alterantive fuel stations
    # Type of fuel by station information
    # Count the number of alterantive fuel facilities by state and add it to the master dataset
    altfuel = pd.read_csv('AlternativeFuelStationLocation.csv')
    # Conform state names
    altfuel['Location'] = altfuel['Location'].str.lower()
    altfuel['Location'] = altfuel['Location'].str.title()
    altfuel = altfuel.replace('District Of Columbia', 'District of Columbia')
    altfuel = altfuel.rename(columns={'Location': 'Name'})
    alt1 = altfuel.groupby(['Name'], as_index = False).size().to_frame('Number of Alt Fuel Facilities')
    dfnew = pd.merge(dfnew, alt1, how='left', on=['Name'])
    return(dfnew)

#Functino to add factories data
def FacSet(dfnew):
    # Import the facility pollution data set
    # Count the number of factories by state and add it to the master data set
    facpol = pd.read_csv('FacilityPollution.csv')
    # Conform state names
    facpol['Location'] = facpol['Location'].str.lower()
    facpol['Location'] = facpol['Location'].str.title()
    facpol = facpol.replace('District Of Columbia', 'District of Columbia')
    facpol = facpol.rename(columns={'Location': 'Name'})
    fp1 = facpol.groupby(['Name'], as_index = False).size().to_frame('Number of Factories')
    dfnew = pd.merge(dfnew, fp1, how='left', on=['Name'])
    return(dfnew)

#Function to add temperature data
def TempSet(dfnew):
    # Read in temperature data that contains full list of lat-longs
    temps_old = pd.read_csv("temps_old.csv")
    
    # Save full list of coordinates
    geos_old = temps_old[['lat','long']]
    geos_old = geos_old.drop_duplicates()
    states = []
    
    ## This section pairs the full list of states with the full lat-long list
        
    # Save full state list back into Python variable
    with open('states.csv', 'r') as f:
      reader = csv.reader(f)
      statelist = list(reader)
    
    # Convert list to array to enable its orientation to be flipped from row to column
    statelist = np.array(statelist)
    # Flip array to column
    statelist = statelist.reshape(-1, 1)
    # Remove null value that ensued from flip
    statelist = statelist[statelist != '']
    
    # Add column of corresponding state names into coordinates dataframe
    geos_old["Name"] = statelist
    
    ## This section pairs the lat-long list we are actually using with its corresponding states list
    
    # Read in temperature data that we are actually using
    temps = pd.read_csv("temps2.csv")
    
    # Save list of states corresponding to coordinates we are actually using
    with open('statelist_final.csv', 'r') as f:
      reader = csv.reader(f)
      statelist_final = list(reader)
    
    # Convert list to array to enable its orientation to be flipped from row to column
    statelist_final = np.array(statelist_final)
    # Flip array to column
    statelist_final = statelist_final.reshape(-1, 1)
    # Remove null value that ensued from flip
    statelist_final = statelist_final[statelist_final != '']
    
    # Save coordinates of points we are actually using
    geos = temps[['lat','long']]
    geos = geos.drop_duplicates()
    
    # Merge full lat-long-state record with lat-long pairs we are using for analysis,
    # leaving only the lat-long-state sets we are actually using
    geoo = pd.merge(geos, geos_old, how='left', on=['lat','long'])
    geoo = geoo.dropna()
    
    # Add column of state names to coordinates we are using for analysis
    geoo['Name'] = statelist_final
    
    # Add state name column to temperatures dataframe
    temperatures = temps.merge(geoo, how = 'inner', on = ['lat', 'long'])
    
    # Define subset dataframe that contains only the numeric temperature data columns
    temp_sub = temperatures[['jan','apr','jul','oct']]
    # Calculate min, max, and mean for each year for each location. Don't include zero values
    # in consideration.
    temperatures['max'] = temp_sub[temp_sub!=0].max(axis=1)
    temperatures['min'] = temp_sub[temp_sub!=0].min(axis=1)
    temperatures['mean'] = temp_sub[temp_sub!=0].mean(axis=1)
    
    # Define lists of the unique years and state names in the dataset
    unique_states = temperatures['Name'].unique()
    unique_years = temperatures['year'].unique()
    
    # Columns that we will eventually add to master dataset
    columns = ['Name','Year','MinT','MaxT','MeanT']
    # Dataframe that we will merge with master dataset
    summary = pd.DataFrame(columns = columns)
    
    # For each state...
    for state in range(0,len(unique_states)):
        
        # Save dataframe that contains only the rows from this state
        matrix = temperatures[temperatures['Name'] == unique_states[state]]
        
        # For each year...
        for year in unique_years:
            
            # Define row that will store this row-year pair's data
            row = pd.DataFrame(columns = columns, index=[0])
            #Label row with state name and year
            row['Name'] = unique_states[state]
            row['Year'] = year
            
            # Define subset of this state's matrix that only contains rows from this year
            new = matrix[matrix['year']==year]
            
            # Calculate mean, min, and max
            row['MeanT'] = new['mean'].mean()
            row['MinT'] = new['min'].mean()
            row['MaxT'] = new['max'].mean()
        
            # Append row containing this state-year pair's state name, year, mean, min, and max
            summary = summary.append(row)
    
    # Merge with the master dataset by state and year
    dfnew = pd.merge(dfnew, summary, how='left', on=['Name', 'Year'])
    return(dfnew)

#Function to add forest data
def ForestSet(dfnew):
    # Import Forest Data
    Forest_Data = pd.read_csv('Forest_Data.csv') 
    
    # Drop region values
    Forest_Data = Forest_Data.rename(columns={'Region': 'Name'})
    Forest_Data = Forest_Data[Forest_Data.Name != 'Northeast Total       ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North total']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Southeast Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'South Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Northwest Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'South total']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Rocky Mountain total:']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Coast total:']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Intermountain Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'United States:     ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Great Plains Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Southwest Total        ']
    
    # reindex 
    Forest_Data = Forest_Data.reset_index(drop=True)
    # make all names matching
    for i in range(len(Forest_Data.Name)):
        Forest_Data.Name[i] = Forest_Data.Name[i].strip() 
        
    # drop years we aren't using
    Forest_Data = Forest_Data.drop(['1997b','1987b','1977b','1963b','1953b','1938b','1920b','1907b','1630c'], axis=1)
    dfnew["Forest Acreage(Thousands)"] =  np.nan
    
    for i in range(len(dfnew)): # loop through all rows of big dataframe
        for j in range(len(Forest_Data)): # loop through all rows of forest_data
            for k in range(3): # loop through columns of Forest_data
                p = k+1 
                if (str(dfnew.Year[i]) == Forest_Data.columns[p] and dfnew.Name[i] == Forest_Data.iloc[j,0]):
                    dfnew["Forest Acreage(Thousands)"][i] = Forest_Data.iloc[j,p]
    
    
    # Convert ints and floats improperly saved as strings to numeric variables
    for i in range(0,len(dfnew)):
        dfnew['Percent increase in urban land 2000-2010'][i] = float(dfnew['Percent increase in urban land 2000-2010'][i])

        if type(dfnew['Forest Acreage(Thousands)'][i]) == str:
            dfnew['Forest Acreage(Thousands)'][i] = dfnew['Forest Acreage(Thousands)'][i].replace(',','')
            dfnew['Forest Acreage(Thousands)'][i] = int(dfnew['Forest Acreage(Thousands)'][i])
    return(dfnew)

#Function to create temp difference
def MaxMinTinc(dfnew):
    dfnew['MaxTInc'] = ''
    dfnew['MinTInc'] = ''
    # Calculate new columns' values for years for which we have previous year's data (i.e. all except 2000)
    # For each row...
    for row in range(0,len(dfnew)):
        # Save off state and year
        state = dfnew['Name'][row]
        year = dfnew['Year'][row]
        # Find row that is same state but in previous year
        plus = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year-1)]
        #Calculate difference between this year's max temp and previous year's max and min temp
        maxTplus = dfnew['MaxT'][row] - plus['MaxT']
        minTplus = dfnew['MinT'][row] - plus['MinT']

    
        # Avoid erroring by skipping if previous year's values didn't exist
        if maxTplus.empty == False:
            # Otherwise, add to temp change column
            dfnew['MinTInc'][row] = minTplus.values[0]
            # Avoid erroring by skipping if previous year's values didn't exist
        if maxTplus.empty == False:
            # Otherwise, add to temp change column
            dfnew['MaxTInc'][row] = maxTplus.values[0]
        
    return(dfnew)
        
# This function creates a dataset that computes differences in each attribute between 2010 and 2000 by state
# These data are used for urbanization analyses
def UrbData(dfnew):
    df1 = dfnew[dfnew.Year == 2000] #take a portion of the data for 2000
    df2 = dfnew[dfnew.Year == 2010] #take a portion of the data for 2010
    #Merge the data together on attributes of interest
    df3 = pd.merge(df1,df2[['Name','Population', 'Passenger Trips','Operating Expenses FY',
            'MinT', 'MaxT', 'MeanT']], on = 'Name', how='left')
    #Loop through the columns and calcualte difference for each attribute
    cols = ['Population', 'Passenger Trips','Operating Expenses FY',
            'MinT', 'MaxT', 'MeanT']
    for col in cols:
        name1 = str(col)+'_x'
        name2 = str(col)+'_y'
        df3[col] = df3[name2] - df3[name1]
        df3 = df3.drop(columns = [name1,name2])
        df3[col] = pd.to_numeric(df3[col]) #make sure the value is numeric
    #Subset just the columns of interest
    df3 = df3[['MaxT','MinT', 'MeanT', 'Percent increase in urban land 2000-2010', 'Population', 'Name', 'Automobiles', 'Buses', 'Trucks', 'Motorcycles', 'Large Airport', 'Medium Airport', 'Small Airport' ]]
    df3['Percent increase in urban land 2000-2010'] = pd.to_numeric(df3['Percent increase in urban land 2000-2010'])
    df3['Population'] = df3['Population']/10000
    df3 = df3.dropna(subset=['Percent increase in urban land 2000-2010']) #drop any rows where urban land data are missing
    df3 = df3.fillna(0) #fill emply cells with 0
    return(df3)

    
#### ANALYSES
    
### Linear Regression 
    
def LR(dfnew):
    # Linear Regression of Max & Min Temps by all attributes of interest 
    print('Linear Regression results for Max Temperatures\n')
    Hypo1LR(dfnew,'MaxT')
    print('Linear Regression results for Min Temperatures\n')
    Hypo1LR(dfnew,'MinT')
    

#Linear Regression             
def Hypo1LR(dfnew, var):
    import statsmodels.api as sm
    d1 = dfnew[['Automobiles','Population','Buses','Trucks','Motorcycles', 'MaxT', 'MinT', 'Year','Name', 'Large Airport', 'Medium Airport','Small Airport', 'Number of Alt Fuel Facilities', 'Number of Factories', 'Hybrid', 'PlugHybrid', 'Electric' ]] 
    d1 = d1.dropna()
    for col in ['Automobiles','Buses','Population','Trucks','Motorcycles', 'MaxT', 'MinT', 'Large Airport', 'Medium Airport','Small Airport', 'Number of Alt Fuel Facilities', 'Number of Factories', 'Hybrid', 'PlugHybrid', 'Electric']:
        d1[col] = d1[col].astype('float')
    
    d1.Name = d1.Name.astype("category").cat.codes
    # Linear Regression of Temp by Car Registrations & Population
    X = d1[['Automobiles','Buses','Trucks','Motorcycles', 'Large Airport', 'Medium Airport','Small Airport', 'Number of Alt Fuel Facilities', 'Number of Factories', 'Hybrid', 'PlugHybrid', 'Electric']]
    Y = d1[var]
    X = sm.add_constant(X) #add a constant to the lm
    model = sm.OLS(Y, X).fit() #fit the model 
    predictions = model.predict(X) #predict values 
    print_model = model.summary() 
    print(print_model) #print model results 

#Granger Causality Analysis
def GC(dfnew):
    print('Granger Causality Analysis Results\n')
    HypoGC(dfnew)

#Granger Causality Analysis Function   
def HypoGC(dfnew):
    from statsmodels.tsa.stattools import grangercausalitytests
    d1 = dfnew[['Automobiles','Population','Buses','Trucks','Motorcycles', 'MaxT', 'MinT', 'Year','Name']] 
    for col in ['Automobiles','Buses','Population','Trucks','Motorcycles', 'MaxT', 'MinT','Year']:
        d1[col] = pd.to_numeric(d1[col])
    d1 = d1.dropna()
    d1.Name = d1.Name.astype("category").cat.codes
    # Print Granger Causality Result for Max T and each of the dependent variables
    print('Granger Causality for Maximum Temperatures\n')
    for col in ['Automobiles','Buses','Trucks','Motorcycles', 'Population']:
        print('\nGranger Causality for ' + col)
        grangercausalitytests(d1[['MaxT', col]], maxlag=2)
    
    # Print Granger Causality Result for Min T and each of the dependent variables
    print('\nGranger Causality for Minimum Temperatures\n')
    for col in ['Automobiles','Buses','Trucks','Motorcycles', 'Population']:
        print('\nGranger Causality for ' + col)
        grangercausalitytests(d1[['MinT', col]], maxlag=2)

#Linear Regression Analysis for Urban Land 
#Using portion of the dataset
def LR2(df3, var):
    import statsmodels.api as sm
    #Define values of X
    X = df3[['Percent increase in urban land 2000-2010','Population','Automobiles', 'Buses', 'Trucks', 'Motorcycles', 'Large Airport', 'Medium Airport', 'Small Airport']]
    #Define values of Y
    Y = df3[var]
    Y = pd.to_numeric(Y) #make sure Y is numeric
    X = sm.add_constant(X) #add a constant to the lm
    model = sm.OLS(Y, X).fit() #fit the model
    predictions = model.predict(X) #predict values 
    print_model = model.summary()
    print(print_model) #print model results 
    
#two sample t test 1 - urban land
def TTest(df3,var):
    from scipy import stats
    # Create a new variable that separates the dataframe into two groups
    df3['IncreaseU'] = np.where(df3['Percent increase in urban land 2000-2010'] > 12.4, 1, 0)
    a = df3[df3.IncreaseU == 1]
    b = df3[df3.IncreaseU == 0]
    a1 = a[var]
    a1 =pd.to_numeric(a1)
    b1 = b[var] 
    b1 =pd.to_numeric(b1) 
    
    # Run t-test for change in maximum temperature of both groups
    tval, pval = stats.ttest_ind(a1,b1)
    print('P value is ', pval,'\n T statistic is ', tval)

#Function performing two sample t test and one way anova
def RegionAnalysis(dfnew):
    import sklearn
    from sklearn.preprocessing import normalize
    import seaborn
    import plotly.graph_objects as go
    import chart_studio.plotly as py
    
    Hypo4Data501 = dfnew[['Name', 'Year','MeanT']] #get required columns
    Hypo4Data501 = pd.DataFrame(Hypo4Data501) # turn data into dataframe
    Hypo4Data501 = Hypo4Data501.dropna() #drop rows with na's
    Hypo4Data501.MeanTChange = np.nan #make new column for differences in temp from year to year 
    StatesNames = pd.DataFrame(Hypo4Data501.Name.unique())
    StatesNames.columns = ['Name']
    StatesNames['TChange'] = np.nan
    
    # loop through all states for each year. calculate the difference in the state's mean temp
    # from the year before. Do this for all states and all years. Also keep track of the means of all the states total
    for i in range(len(StatesNames.Name)):
        dataF = Hypo4Data501.loc[Hypo4Data501.Name == StatesNames.Name[i]]
        dataF = dataF.reset_index(drop=True)
        lst = [0] * len(dataF)
        lst = np.array(lst)
        for j in range(len(dataF)):
            if j != 0:
                diff = dataF.MeanT[j]-dataF.MeanT[j-1]
                Hypo4Data501.loc[(Hypo4Data501['Name']==dataF.Name[j]) & (Hypo4Data501.Year==dataF.Year[j]), 'MeanTChange'] = diff
                lst[j] = diff
        mdiffA = np.array(lst)
        mdiff = np.mean(mdiffA)
        StatesNames.TChange[i] = mdiff #means of all the states mean differences per year
        
    #form North group
    NorthStates = StatesNames[StatesNames['Name'].isin(['Alaska', 'Connecticut','Idaho','Illinois','Indiana','Iowa','Maine','Massachusetts','Michigan','Minnesota',
                              'Montana','Nebraska','New Hampshire','New Jersey','New York','North Dakota','Ohio','Oregon','Pennsylvania','Rhode Island'
                              'South Dakota','Vermont','Washington','Wisconsin','Wyoming'])]
    SouthStates = StatesNames[StatesNames['Name'].isin(['Alabama','Arizona','Arkansas','California','Colorado','Delaware','District of Columbia','Florida',
                              'Georgia','Hawaii','Kansas','Kentucky','Louisiana','Mississippi','Missouri','Nevada','New Mexico','North Carolina','Oklahoma',
                              'South Carolina','Tennessee','Texas','Utah','Virginia','West Virginia', 'Maryland'])]
    
    NorthStates = pd.DataFrame(NorthStates)
    SouthStates = pd.DataFrame(SouthStates)
    print(NorthStates.mean(axis = 0) ) #mean of north
    print(SouthStates.mean(axis = 0) ) #mean of south
    print(stats.ttest_ind(NorthStates['TChange'],SouthStates['TChange']))
    Hypo4Data501N = Hypo4Data501[Hypo4Data501['Name'].isin(['Alaska', 'Connecticut','Idaho','Illinois','Indiana','Iowa','Maine','Massachusetts','Michigan','Minnesota',
                              'Montana','Nebraska','New Hampshire','New Jersey','New York','North Dakota','Ohio','Oregon','Pennsylvania','Rhode Island'
                              'South Dakota','Vermont','Washington','Wisconsin','Wyoming'])]
    Hypo4Data501S = Hypo4Data501[Hypo4Data501['Name'].isin(['Alabama','Arizona','Arkansas','California','Colorado','Delaware','District of Columbia','Florida',
                              'Georgia','Hawaii','Kansas','Kentucky','Louisiana','Mississippi','Missouri','Nevada','New Mexico','North Carolina','Oklahoma',
                              'South Carolina','Tennessee','Texas','Utah','Virginia','West Virginia', 'Maryland'])]
    
    #set up time series boxplots for each region     
    ts = pd.Series(Hypo4Data501N['MeanTChange'], index=Hypo4Data501N.Year)
    fig, ax = plt.subplots(figsize=(12,5))
    seaborn.boxplot(x = ts.index, y = Hypo4Data501N['MeanTChange'], ax=ax).set_title("North States Mean Temperature Changes")
    
    ts = pd.Series(Hypo4Data501S['MeanTChange'], index=Hypo4Data501S.Year)
    fig, ax = plt.subplots(figsize=(12,5))
    seaborn.boxplot(x = ts.index, y = Hypo4Data501S['MeanTChange'], ax=ax).set_title("South States Mean Temperature Changes")
    
    # plot Temp changes overall on US map
    codes = ['AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME',
             'MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN',
             'TX','UT','VT','VA','WA','WV','WI','WY']
    StatesNames['Abr'] = codes
    
    fig = go.Figure(data=go.Choropleth(
        locations=StatesNames['Abr'], # get locations correct
        z = StatesNames['TChange'].astype(float), # color data by temp change 
        locationmode = 'USA-states', # set of locations match entries in `locations`
        colorscale = 'Reds',
        colorbar_title = "Temp Change",
        marker_line_color='white'
    ))
    
    fig.update_layout(
        title =  dict( text = '2000-2018 USA Temperature Change in Celsius', font =dict(size=18, color = 'black')),
        geo_scope='usa', # limite map scope to USA
    )
    
    fig.show()
    fig.write_image("fig1.png") #export as png to folder
    py.plot(fig, filename='2000-2018 USA Temperature Change in Celsius.html')
    
    # test regions 
    NorthEast = StatesNames[StatesNames['Name'].isin(['Connecticut','Maine','Massachusetts','New Hampshire','New Jersey','New York',
                            'Pennsylvania','Rhode Island','Vermont'])]
    MidWest = StatesNames[StatesNames['Name'].isin(['Illinois','Indiana','Iowa','Michigan','Minnesota','Kansas',
                             'Nebraska','North Dakota','Ohio','South Dakota','Wisconsin','Missouri'])]
    South = StatesNames[StatesNames['Name'].isin(['Alabama','Arkansas','Florida', 'Georgia','Kentucky','Louisiana','Mississippi','District of Columbia',
                            'North Carolina','Oklahoma', 'South Carolina','Tennessee','Texas','Virginia','West Virginia','Maryland','Delaware'])]
    West = StatesNames[StatesNames['Name'].isin(['Arizona','California','Colorado','Wyoming','Alaska','Oregon','Montana','Washington',
                              'Hawaii','Nevada','New Mexico','Utah','Virginia',])]
    NorthEast = pd.DataFrame(NorthEast)
    MidWest = pd.DataFrame(MidWest)
    South = pd.DataFrame(South)
    West = pd.DataFrame(West)
    print(NorthEast['TChange'].mean(axis = 0) )
    print(MidWest['TChange'].mean(axis = 0) )
    print(South['TChange'].mean(axis = 0) )
    print(West['TChange'].mean(axis = 0) )
    NorthEast = np.array(NorthEast['TChange']) #get array of data
    MidWest = np.array(MidWest['TChange']) #get array of data
    South = np.array(South['TChange']) #get array of data
    West =  np.array(West['TChange']) #get array of data
    NorthEast=np.reshape(NorthEast,(-1, 1)) # reshape array
    MidWest=np.reshape(MidWest,(-1, 1))# reshape array
    West=np.reshape(West,(-1, 1))# reshape array
    South=np.reshape(South,(-1, 1))# reshape array
    NorthEast=sklearn.preprocessing.normalize(NorthEast) # normalize
    MidWest=sklearn.preprocessing.normalize(MidWest)# normalize
    West=sklearn.preprocessing.normalize(West)# normalize
    South=sklearn.preprocessing.normalize(South)# normalize
    print(stats.f_oneway(NorthEast, MidWest, South, West))
    
    
    Hypo4Data501NE = Hypo4Data501[Hypo4Data501['Name'].isin(['Connecticut','Maine','Massachusetts','New Hampshire','New Jersey','New York',
                            'Pennsylvania','Rhode Island','Vermont'])]
    Hypo4Data501MW = Hypo4Data501[Hypo4Data501['Name'].isin(['Illinois','Indiana','Iowa','Michigan','Minnesota','Kansas',
                             'Nebraska','North Dakota','Ohio','South Dakota','Wisconsin','Missouri'])]
    Hypo4Data501SS = Hypo4Data501[Hypo4Data501['Name'].isin(['Alabama','Arkansas','Florida', 'Georgia','Kentucky','Louisiana','Mississippi','District of Columbia',
                            'North Carolina','Oklahoma', 'South Carolina','Tennessee','Texas','Virginia','West Virginia','Maryland','Delaware'])]
    Hypo4Data501W = Hypo4Data501[Hypo4Data501['Name'].isin(['Arizona','California','Colorado','Wyoming','Alaska','Oregon','Montana','Washington',
                              'Hawaii','Nevada','New Mexico','Utah','Virginia',])]
        
    #set up time series boxplots for each region     
    ts = pd.Series(Hypo4Data501NE['MeanTChange'], index=Hypo4Data501NE.Year)
    fig, ax = plt.subplots(figsize=(12,5))
    seaborn.boxplot(x = ts.index, y = Hypo4Data501NE['MeanTChange'], ax=ax).set_title("Northeast Region: Mean Temperature Changes")
    
    ts = pd.Series(Hypo4Data501MW['MeanTChange'], index=Hypo4Data501MW.Year)
    fig, ax = plt.subplots(figsize=(12,5))
    seaborn.boxplot(x = ts.index, y = Hypo4Data501MW['MeanTChange'], ax=ax).set_title("Midwest Region: Mean Temperature Changes")
    
    ts = pd.Series(Hypo4Data501SS['MeanTChange'], index=Hypo4Data501SS.Year)
    fig, ax = plt.subplots(figsize=(12,5))
    seaborn.boxplot(x = ts.index, y = Hypo4Data501SS['MeanTChange'], ax=ax).set_title("South Region: Mean Temperature Changes")
    
    ts = pd.Series(Hypo4Data501W['MeanTChange'], index=Hypo4Data501W.Year)
    fig, ax = plt.subplots(figsize=(12,5))
    seaborn.boxplot(x = ts.index, y = Hypo4Data501W['MeanTChange'], ax=ax).set_title("West Region: Mean Temperature Changes")

    fig = go.Figure()
    for year in set(Hypo4Data501NE.Year):
        fig.add_trace(go.Box(y=Hypo4Data501NE.MeanTChange[Hypo4Data501NE.Year==year], name=year,
                        marker_color = 'indianred'))    
    fig.show()
    py.plot(fig, filename='2000-2018 USA Temperature Change in Celsius.html')
    
#random forest
def Prep(dfnew):
    
    import statistics 
    import math 
    #pip install mlxtend
    #from mlxtend.frequent_patterns import association_rules, apriori

    from apyori import apriori

    # Approximate null temperature values for DC 2015-2019 using linear approximation
    # from the two previous years

    # Set state name constant
    state = 'District of Columbia'
    # For each year...
    for year in range(2015,2019):
        # Save row of interest
        record = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year)].index.values[0]
        # Obtain row from previous year
        record1 = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year-1)].index.values[0]
        # Obtain row from two years prior
        record2 = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year-2)].index.values[0]
        # Calculate approximations using two previous years' numbers
        dfnew['MeanT'][record] = dfnew['MeanT'][record1] + (dfnew['MeanT'][record1] - dfnew['MeanT'][record2])
        dfnew['MaxT'][record] = statistics.mean([dfnew['MaxT'][record1], dfnew['MaxT'][record2]])
        dfnew['MinT'][record] = statistics.mean([dfnew['MinT'][record1], dfnew['MinT'][record2]])

    # Replace null values in airport type columns with zeros, as nulls likely are indicative of a value of 0
    dfnew[['Balloonport','Heliport','Large Airport','Medium Airport','Seaplane Base','Small Airport']] = dfnew[['Balloonport','Heliport','Large Airport','Medium Airport','Seaplane Base','Small Airport']].replace(np.nan,0)

    # Define empty columns that will become population change from previous and 
    # population percentage change from previous year
    dfnew['Pop_Increase'] = ''
    dfnew['Pop_Percent_Increase'] = ''


    # Calculate new columns' values for years for which we have previous year's data (i.e. all except 2000)

    # For each row...
    for row in range(0,len(dfnew)):
        # Save off state and year
        state = dfnew['Name'][row]
        year = dfnew['Year'][row]
        # Find row that is same state but in previous year
        plus = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year-1)]
        # Calculate difference between this year's pop and previous year's pop
        popplus = dfnew['Population'][row] - plus['Population']
        #Calculate difference between this year's max temp and previous year's max temp
        maxTplus = dfnew['MaxT'][row] - plus['MaxT']
        # Calculate percentage change between this year's pop and previous year's pop
        popplus_percent = popplus/plus['Population']
    
        # Avoid erroring by skipping if previous year's values did not exist (null or 1999)
        if plus.empty == False:
            # Add population statistics to this row
            dfnew['Pop_Increase'][row] = popplus.values[0]
            dfnew['Pop_Percent_Increase'][row] = popplus_percent.values[0]

                    
    # Approximate new columns' values for year 2000 through linear approximation
    # Assume that 1999->2000 change was similar to 2000->2001 change.
    for row in dfnew[dfnew['Pop_Increase']==''].index:
        state = dfnew['Name'][row]
        year = dfnew['Year'][row]
        plus = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year+1)]
        popplus = plus['Population'] - dfnew['Population'][row]
        popplus_percent = popplus/dfnew['Population'][row]
        dfnew['Pop_Increase'][row] = popplus.values[0]
        dfnew['Pop_Percent_Increase'][row] = popplus_percent.values[0]
        
    return(dfnew)
    
    
## Binning - bin each of 8 variables using k=4. Inspect with histogram and then
## choose appropriate binwidths. General goal is equi-depth, while also trying
## to capture stark separations in value concentrations and negative vs. positive
# in the case of population change.
def Bin(dfnew): 
    
    # Create bins for total count of medium+large airports
    dfnew['Airports'] = dfnew['Large Airport'] + dfnew['Medium Airport']
    #dfnew['Airports'].hist()
    dfnew['AeroBins'] = pd.cut(dfnew['Airports'],[-1,10,22,40,65])
    dfnew['AeroBins'] = dfnew['AeroBins'].astype('category')
    dfnew['AeroBins'] = dfnew['AeroBins'].cat.codes    


    # Create bins for population percentage increase
    #dfnew['Pop_Percent_Increase'].hist()
    dfnew['PopChangeBins'] = pd.cut(dfnew['Pop_Percent_Increase'],[-.07,0,.01,.02,.05])
    dfnew['PopChangeBins'] = dfnew['PopChangeBins'].astype('category')
    dfnew['PopChangeBins'] = dfnew['PopChangeBins'].cat.codes

    # Create bins for automobile count
    #dfnew['Automobiles'].hist()
    dfnew['AutoBins'] = pd.cut(dfnew['Automobiles'],[-.01,1e6,3e6,1e7,2.2e7])
    dfnew['AutoBins'] = dfnew['AutoBins'].astype('category')
    dfnew['AutoBins'] = dfnew['AutoBins'].cat.codes  
    
    # Create bins for total population
    #dfnew['Population'].hist()
    dfnew['PopBins'] = pd.cut(dfnew['Population'],[-1,1e6,5e6,1e7,4e7])
    dfnew['PopBins'] = dfnew['PopBins'].astype('category')
    dfnew['PopBins'] = dfnew['PopBins'].cat.codes 

    # Create bins for mean temperature
    #dfnew['MeanT'].hist()
    dfnew['TBins'] = pd.cut(dfnew['MeanT'],[-5,5,10,18,25])
    dfnew['TBins'] = dfnew['TBins'].astype('category')
    dfnew['TBins'] = dfnew['TBins'].cat.codes

    # Create bins for truck counts
    #dfnew['Trucks'].hist()
    dfnew['TruckBins'] = pd.cut(dfnew['Trucks'],[0,6e4,1e6,2e6,15e6])
    dfnew['TruckBins'] = dfnew['TruckBins'].astype('category')
    dfnew['TruckBins'] = dfnew['TruckBins'].cat.codes

    # Create bins for bus counts
    #dfnew['Buses'].hist()
    dfnew['BusBins'] = pd.cut(dfnew['Buses'],[-1,10000,20000,40000,120000])
    dfnew['BusBins'] = dfnew['BusBins'].astype('category')
    dfnew['BusBins'] = dfnew['BusBins'].cat.codes

    # Create bins for urban land increase percentages
    #dfnew['Percent increase in urban land 2000-2010'].hist()
    dfnew['UrbanBins'] = pd.cut(dfnew['Percent increase in urban land 2000-2010'],[-1,7,15,20,30])
    dfnew['UrbanBins'] = dfnew['UrbanBins'].astype('category')
    dfnew['UrbanBins'] = dfnew['UrbanBins'].cat.codes

    return(dfnew)

        
def RF(dfnew):

    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    from sklearn import preprocessing
    from sklearn.model_selection import train_test_split
    from sklearn.model_selection import KFold
    from sklearn.model_selection import cross_val_score
    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import accuracy_score
    from sklearn.metrics import classification_report
    
    dfnew = Prep(dfnew)
    dfnew = Bin(dfnew)
    
    # Save dataframe that is solely Olympic years, but remove Puerto Rico because we don't have temp data
    rf = dfnew[(dfnew['Year'].isin([2000,2004,2008,2012,2016])) & (dfnew['Name'] != 'Puerto Rico')]
    # Define empty column that will store change in max temperature over the previous 4 years
    rf['MaxTInc4'] = ''

    # For each row...
    for row in rf.index:
        # Save off state and year
        state = rf['Name'][row]
        year = rf['Year'][row]
        # We will not have a temperature change number for 2000 (because we don't have data from 1996 in the dataframe), so don't calculate for that year
        if year != 2000:
            # Find row that is same state but 4 years prior
            plus = rf[(rf['Name'] == state) & (rf['Year'] == year-4)]
            #Calculate difference between this year's max temp and max temp in this state 4 years prior
            maxTplus = rf['MaxT'][row] - plus['MaxT']
            # Otherwise, add to temp change column
            rf['MaxTInc4'][row] = maxTplus.values[0]

    # Remove year-2000 columns because it has served its purpose of helping generate values for year-2004 rows
    rf = rf[rf['Year'] != 2000]
    # Sort temperature change values to allow for bin edges to be defined
    values = sorted(rf['MaxTInc4'])
    # Calculate equi-depth bin edges
    edges = [values[0]-.01,values[50]+.001,values[101]+.001,values[152]+.001,values[203]+.01]
    # Assign category variable, the class that we will test for, based on bins
    rf['Class'] = pd.cut(rf['MaxTInc4'], bins=edges)
    # Make class a category variable
    rf['Class'] = rf['Class'].astype('category')
    # Encode category variable as numbers
    rf['Class'] = rf['Class'].cat.codes    

    ## Remove null values from vehicular rows by assuming linear approximation between 2008 and 2012
    ## continues for 2016 (i.e. change from 2012 to 2016 is approximately the same as change from 2008 to 2012)
    # List columns that we want to approximate
    vehicles = ['Automobiles','Buses','Trucks','Motorcycles']
    # For each row
    for i in rf.index:
        # For each column
        for vehicle in vehicles:
            # If value is null...
            if np.isnan(rf[vehicle][i]) == True:
                # Obtain row containing 2012 data for that state
                goodrow1 = rf[(rf['Year'] == 2012) & (rf['Name'] == rf['Name'][i])]
                goodrow2 = rf[(rf['Year'] == 2008) & (rf['Name'] == rf['Name'][i])]
                # Save 2012 + (2012-2008) data in this row (which is a year-2016 row because 
                # those are the only rows containing null values for these columns)
                rf[vehicle][i] = goodrow1[vehicle].values[0] + goodrow1[vehicle].values[0] - goodrow2[vehicle].values[0]


    # Save variables that I want to test
    rf_input = rf[['Year','Automobiles','Buses','Trucks','Motorcycles','Heliport','Airports','NE','SE','PS','NC','SC','RM','GP','PN','Percent increase in urban land 2000-2010','Number of Alt Fuel Facilities','Pop_Increase','Pop_Percent_Increase','Class']]

    # Save data to be classified to array
    valueArray = rf_input.values
    # Save array that removes the temperature increase classifier
    X = valueArray[:, 0:19]
    # Normalize values in this array
    preprocessing.normalize(X)
    # save temperature increase classes to separate array
    Y = valueArray[:, 19]
    Y = Y.astype('int')

    ## First, I'm going to evaluate the applicability of random forest to this dataset
    # generally by running creating a test set of 20% of the full dataset and running 2-fold validation.
    
    # Identify proportion of the dataset - 20% - that will be used for testing
    test_size = 0.20
    # Random state
    seed = 7
    # Separate dataset into training and test portions
    X_train, X_validate, Y_train, Y_validate = train_test_split(X, Y, test_size=test_size, random_state=seed)

    # Define model
    model = RandomForestClassifier(n_estimators=20)
    # Define number of folds
    kfold = KFold(n_splits=5, random_state=seed, shuffle=False)
    # Perform 2-fold cross-validation on the training set.
    results = cross_val_score(model, X_train, Y_train, cv=kfold, scoring='accuracy')

    # Print data on classifier's performance for training data
    print("RF's performance vis-a-vis training data: mean = ",str(results.mean()), ", Std Dev = ", str(results.std()))
   
    # Use classifier to predict classes for test set
    model.fit(X_train, Y_train)
    predictions = model.predict(X_validate)

    # Print performance on test set
    print("\nRF's performance vis-a-vis test data:\nAccuracy: ",accuracy_score(Y_validate, predictions))
    print("Confusion Matrix:\n",confusion_matrix(Y_validate, predictions))
    print("Classification Report:\n",classification_report(Y_validate, predictions))  


    ## I'm also going to use Random Forest to help evaluate our hypothesis regarding the relative importance
    ## of each variable for predicting temperature rise.

    # Run Random Forest on full dataset
    model.fit(X, Y)  
    # Calculate relative importance of each feature
    final = model.feature_importances_
    # Print importance coefficients alongside column names
    printout = pd.DataFrame(rf_input.columns[:-1], final)
    printout

    ## This section of the code was used to visualize all trees
    ## from our random forest, but we have commented it out to
    ## save you time and memory.
    
    # Making graphs of the individual random forest trees
    # for i in range(0,len(model.estimators_)):
        #name = 'tree' + str(i) + '.png'
    
        #estimator = model.estimators_[i]
    
        #from sklearn.tree import export_graphviz
        # Export as dot file
        #export_graphviz(estimator, out_file='tree.dot', 
                        #feature_names = iris.feature_names,
                        #class_names = iris.target_names,
                        #rounded = True, proportion = False, 
                        #precision = 2, filled = True)
        
        #from subprocess import call
        #call(['dot', '-Tpng', 'tree.dot', '-o', name, '-Gdpi=600'])

      
if __name__ == '__main__':
    Main()


