#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec  7 13:13:41 2019

@author: mashagubenko
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 12:24:44 2019

@author: mashagubenko
"""
import plotly.graph_objects as go
import pandas as pd
import plotly.express as px



def Main():
    dfnew = MasterDataSet() #create master dataset 
    BarG1(dfnew) #bar graph of
    MinSouthNorthTime(dfnew) #min temperature over time by region 
    MaxSouthNorthTime(dfnew) #max temperature over time by region
    MinTempTime(dfnew) #min temperature by state over time
    MaxTempTime(dfnew) #max temperature by state over time
    AirportLand(dfnew) #number of airports by type by state
    
    df3 = UrbData(dfnew) #create urban land dataset
    UrbLanGraph(df3) #urban land increase between 2000 and 2010 by state
    UrbLanHist(df3) #urban land increase distribution
    
    EVGraph() #electric vehicle registration data over time 
    
######### DATA PREPROCESSING ######################

# This function creates a master dataset of all our data 
def MasterDataSet():    
    new = PopSet() #calling a function to create a dataframe of population data
    dfnew = TransitSet(new) #calling a function to add transit data
    dfnew = VehRegSet(dfnew) #calling a function to add veh reg data    
    dfnew = ElecSet(dfnew)  #calling a function to add electric vehicle data
    dfnew = AirportSet(dfnew)  #calling a function to add airport data
    dfnew = RegSet(dfnew)  #calling a function to add regions data
    dfnew = UrbSet(dfnew)  #calling a function to add urban land data
    dfnew = AltFuelSet(dfnew) #calling a function to alt facilities data
    dfnew = FacSet(dfnew) #calling a function to factories data
    dfnew = TempSet(dfnew)  #calling a function to add temperature data
    dfnew = ForestSet(dfnew)  #calling a function to add forest data
    dfnew = MaxMinTinc(dfnew)  #calling a function to create temp difference 
    
    dfnew['CarPC'] = dfnew['Automobiles']/dfnew.Population #creating a car per capita variable
    dfnew['TruckPC'] = dfnew['Trucks']/dfnew.Population #creating a truck per capita variable
    dfnew['BusPC'] = dfnew['Buses']/dfnew.Population  #creating a bus per capita variable
    dfnew['MCPC'] = dfnew['Motorcycles']/dfnew.Population #creating a motorcycle per capita variable
    dfnew['LAPC'] = dfnew['Large Airport']/dfnew.Population #creating a large airport per capita variable
    dfnew['MAPC'] = dfnew['Medium Airport']/dfnew.Population #creating a med airport per capita variable
    dfnew['SAPC'] = dfnew['Small Airport']/dfnew.Population #creating a small airport per capita variable
    
    return(dfnew) #return the final dataframe

#Functino to read in popuation data
def PopSet():
    # Start the master data set by setting a dataframe of all states' 
    # populations by year 
    # Import the population info by State
    popstate = pd.read_csv('Population_by_State_by_Year_2000_2010.csv')
    popstate = popstate.drop(columns=['Unnamed: 0','census2010pop','estimatesbase2000'])
    colpop = popstate.columns
    
    new = pd.DataFrame(columns=['Name', 'Population', 'Year'])
    # Loop through every column and add it as time series information for each state
    for col in colpop[1:len(colpop)]:
        df = popstate[['name',col]]
        df = df.groupby('name',as_index=False).max()
        df = df.rename(columns={col: 'Population', 'name':'Name'})
        df['Year'] = int(col[len(col)-4:len(col)])
        new = pd.concat([new,df],ignore_index=True) #combine the dataframes into one of all years
        
    # Import the population info by State part 2
    popstate = pd.read_csv('nst-est2018-alldata.csv')
    # Loop through every column and add it as time series information for each state
    popstate = popstate[['NAME', 'POPESTIMATE2011',
           'POPESTIMATE2012', 'POPESTIMATE2013', 'POPESTIMATE2014',
           'POPESTIMATE2015', 'POPESTIMATE2016', 'POPESTIMATE2017',
           'POPESTIMATE2018']]
    popstate = popstate.drop(popstate.index[[0,1,2,3,4]])
    colpop = popstate.columns
    
    new2 = pd.DataFrame(columns=['Name', 'Population', 'Year'])
    for col in colpop[1:len(colpop)]:
        df = popstate[['NAME',col]]
        df = df.groupby('NAME',as_index=False).max()
        df = df.rename(columns={col: 'Population', 'NAME':'Name'})
        df['Year'] = int(col[len(col)-4:len(col)])
        new2 = pd.concat([new2,df],ignore_index=True) #combine the dataframes into one of all years
    
    # Combine the two parts of population datasets into one
    new = pd.concat([new,new2],ignore_index=True)    
    
    return(new)

#Function to read in transit data
def TransitSet(new):
    # List of all states to change abbreviations to full names
    states = {
            'AK': 'Alaska',
            'AL': 'Alabama',
            'AR': 'Arkansas',
            'AS': 'American Samoa',
            'AZ': 'Arizona',
            'CA': 'California',
            'CO': 'Colorado',
            'CT': 'Connecticut',
            'DC': 'District of Columbia',
            'DE': 'Delaware',
            'FL': 'Florida',
            'GA': 'Georgia',
            'GU': 'Guam',
            'HI': 'Hawaii',
            'IA': 'Iowa',
            'ID': 'Idaho',
            'IL': 'Illinois',
            'IN': 'Indiana',
            'KS': 'Kansas',
            'KY': 'Kentucky',
            'LA': 'Louisiana',
            'MA': 'Massachusetts',
            'MD': 'Maryland',
            'ME': 'Maine',
            'MI': 'Michigan',
            'MN': 'Minnesota',
            'MO': 'Missouri',
            'MP': 'Northern Mariana Islands',
            'MS': 'Mississippi',
            'MT': 'Montana',
            'NA': 'National',
            'NC': 'North Carolina',
            'ND': 'North Dakota',
            'NE': 'Nebraska',
            'NH': 'New Hampshire',
            'NJ': 'New Jersey',
            'NM': 'New Mexico',
            'NV': 'Nevada',
            'NY': 'New York',
            'OH': 'Ohio',
            'OK': 'Oklahoma',
            'OR': 'Oregon',
            'PA': 'Pennsylvania',
            'PR': 'Puerto Rico',
            'RI': 'Rhode Island',
            'SC': 'South Carolina',
            'SD': 'South Dakota',
            'TN': 'Tennessee',
            'TX': 'Texas',
            'UT': 'Utah',
            'VA': 'Virginia',
            'VI': 'Virgin Islands',
            'VT': 'Vermont',
            'WA': 'Washington',
            'WI': 'Wisconsin',
            'WV': 'West Virginia',
            'WY': 'Wyoming'
    }
    
    
    # Import the transit data
    # Annual
    # Years 2002 - 2017 (most data for 2017)
    # Location as Lat/Long and City Name
    # Add to the master data set each piece of info from the transit data set by state by year 
    transit = pd.read_csv('TransitwithLatLong.csv')
    stat = transit['HQ State'].apply(lambda x: states[x]) #create a list of all states
    transit['HQ State'] = stat #add a column of all states
    #Total trips by state by year
    a = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Unlinked Passenger Trips FY'].sum()
    a = a.rename(columns={'FY End Year': 'Year', 'HQ State':'Name', 'Unlinked Passenger Trips FY': 'Passenger Trips'})
    #Largest service area by state by year
    b = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Service Area SQ Miles'].max()
    b = b.rename(columns={'FY End Year': 'Year', 'HQ State':'Name', 'Service Area SQ Miles': 'Largest Transit Service Area'})
    #Total trips by state by year
    c = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Operating Expenses FY'].sum()
    c = c.rename(columns={'FY End Year': 'Year', 'HQ State':'Name'})
    
    # Add transit info to the master dataframe by state and year
    dfnew = pd.merge(new, a, how='left', on=['Name', 'Year'])
    dfnew = pd.merge(dfnew, b, how='left', on=['Name', 'Year'])
    dfnew = pd.merge(dfnew, c, how='left', on=['Name', 'Year'])
    
    return(dfnew)

#Function to add vehicle reg data    
def VehRegSet(dfnew):
    # Import the vehicle registration data
    # Annual by State
    # Location as state
    # Years 1995 - 2014
    # Add the data to the master dataset by state by year 
    vehreg = pd.read_csv('Vehicle_Registration_By_State_By_Year.csv')
    vehreg = vehreg.drop(columns=['Unnamed: 0', 'index'])
    vehreg = vehreg.rename(columns = {'State': 'Name', 'Motorcicles': 'Motorcycles'})
    # Conform state names
    vehreg.Name = vehreg.Name.str.replace(r'[\(\)\d]+', '')
    vehreg.Name = vehreg.Name.str.replace('/','')
    vehreg = vehreg.replace('Dist. of Col.', 'District of Columbia')
    
    # Clean the state names information for state names neding in ' ' or '  '
    for k in vehreg.Name:
        if k[len(k)-1] == ' ':
            if k[len(k)-2] == ' ':
                vehreg = vehreg.replace(k, k[0:len(k)-2])
            else:
                vehreg = vehreg.replace(k, k[0:len(k)-1])
                
    # Add to the master dataframe by state and year
    dfnew = pd.merge(dfnew, vehreg, how='left', on=['Name', 'Year'])
    for col in ['Automobiles', 'Buses', 'Trucks','Motorcycles']:
        dfnew[col] = dfnew[col]
    return(dfnew)

#Functino to add electric vehicle data
def ElecSet(dfnew):
    # Import the data set on electric vehicle registrations 
    # Annual 
    # Aggregated for the entire country by vehicle type & year so location is US
    # Years: 1999-2017
    evreg = pd.read_csv('EV_Registrations_by_Type_US_by_Year.csv')
    evreg = evreg.drop(columns=['Unnamed: 0','Unnamed: 0.1'])
    evreg = evreg.replace('U',0) #replace empty values with 0s 
    colev = evreg.columns
    
    # Add the ev registration data to the master dataset
    # Total number of ev registrations in the US is added to each state for each type of ev
    dfnew['Hybrid'] = 0 
    dfnew['PlugHybrid'] = 0 
    dfnew['Electric'] = 0 
    # Add a column of total values by state by year 
    for col in colev:
        dfnew['Hybrid'].mask(dfnew['Year']== int(col), evreg[col][0], inplace=True)
        dfnew['PlugHybrid'].mask(dfnew['Year']== int(col), evreg[col][1], inplace=True)
        dfnew['Electric'].mask(dfnew['Year']== int(col), evreg[col][2], inplace=True)
    
    # Estimate state level values by dividing the country totals by population 
    dfnew['Hybrid'] = pd.to_numeric(dfnew['Hybrid'])
    dfnew['PlugHybrid'] = pd.to_numeric(dfnew['PlugHybrid'])
    dfnew['Electric'] = pd.to_numeric(dfnew['Electric'])
    dfnew['Hybrid'] = dfnew['Hybrid']/dfnew['Population']
    dfnew['PlugHybrid'] = dfnew['PlugHybrid']/dfnew['Population']
    dfnew['Electric'] = dfnew['Electric']/dfnew['Population']
    return(dfnew)

#Function to add airport data    
def AirportSet(dfnew):
    # Import the data on airport location
    # Add number of airports by type by state to the master dataset
    airloc = pd.read_csv('AirportLocation.csv') 
    # Conform state names
    airloc['Location'] = airloc['Location'].str.lower()
    airloc['Location'] = airloc['Location'].str.title()
    airloc = airloc.replace('District Of Columbia', 'District of Columbia')
    airloc = airloc[airloc['type'] != 'closed'] #drop the rows where airports have been closed
    airloc = airloc.rename(columns={'Location': 'Name'})
    
    # Split into dataframes for each airport type
    a1 = airloc[airloc['type'] == 'balloonport']
    a2 = airloc[airloc['type'] == 'heliport']
    a3 = airloc[airloc['type'] == 'large_airport']
    a4 = airloc[airloc['type'] == 'medium_airport']
    a5 = airloc[airloc['type'] == 'seaplane_base']
    a6 = airloc[airloc['type'] == 'small_airport']
    
    # Aggregate the totals of each type of airprot by state by year 
    # And merge with the master data frame
    a11 = a1.groupby(['Name'], as_index = False).size().to_frame('Balloonport')
    dfnew = pd.merge(dfnew, a11, how='left', on=['Name'])
    a21 = a2.groupby(['Name'], as_index = False).size().to_frame('Heliport')
    dfnew = pd.merge(dfnew, a21, how='left', on=['Name'])
    a31 = a3.groupby(['Name'], as_index = False).size().to_frame('Large Airport')
    dfnew = pd.merge(dfnew, a31, how='left', on=['Name'])
    a41 = a4.groupby(['Name'], as_index = False).size().to_frame('Medium Airport')
    dfnew = pd.merge(dfnew, a41, how='left', on=['Name'])
    a51 = a5.groupby(['Name'], as_index = False).size().to_frame('Seaplane Base')
    dfnew = pd.merge(dfnew, a51, how='left', on=['Name'])
    a61 = a6.groupby(['Name'], as_index = False).size().to_frame('Small Airport')
    dfnew = pd.merge(dfnew, a61, how='left', on=['Name'])
    return(dfnew)

#Functino to add region data
def RegSet(dfnew):
    # Set up lists of states belonging to each region
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']    
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    # Set up columns corresponding to each of the region in the master dataset
    reg = ['NE','SE','PS','NC','SC','RM','GP','PN']
    for lst in reg:
        dfnew[lst] = 0
    
    # Loop through the lists of regions and identify states that belong to 
    # each region by assigning 1 to that column    
    reglist = [NE,SE,PS,NC,SC,RM,GP,PN]       
    i = 0 
    while i < len(reglist):  
        #print(reg[i])
        for j in range(0,len(dfnew['Name'])):
            if dfnew['Name'][j] in reglist[i]:
                dfnew[reg[i]][j] = 1
        i += 1
    return(dfnew)

#Function to add Urban Land data
def UrbSet(dfnew):
    # Set up lists of states belonging to each region
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']
    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']
    
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']
    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']
    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']
    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']
    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    # Set up columns corresponding to each of the region in the master dataset
    reg = ['NE','SE','PS','NC','SC','RM','GP','PN']
    # Import the urban land data set
    urbland = pd.read_csv('Urban_Land(2000-2010).csv') 
    urbland = urbland.drop(urbland.index[[0,9]]) # Drop totals
    
    # Pull the data from the urban data set on growth % of urban land by each region
    # Add the total % increase to each state belonging to the region in the master dataset    
    dfnew['Percent increase in urban land 2000-2010'] = 0
    for i in range(0, len(reg)-1):
        dfnew['Percent increase in urban land 2000-2010'].mask(dfnew[reg[i]] == 1, urbland['Percent increase in urban land 2000-2010'][i+1] , inplace=True)
    return(dfnew)

#Function to add alt fuel data
def AltFuelSet(dfnew):
    # Import the data set on alterantive fuel stations
    # Type of fuel by station information
    # Count the number of alterantive fuel facilities by state and add it to the master dataset
    altfuel = pd.read_csv('AlternativeFuelStationLocation.csv')
    # Conform state names
    altfuel['Location'] = altfuel['Location'].str.lower()
    altfuel['Location'] = altfuel['Location'].str.title()
    altfuel = altfuel.replace('District Of Columbia', 'District of Columbia')
    altfuel = altfuel.rename(columns={'Location': 'Name'})
    alt1 = altfuel.groupby(['Name'], as_index = False).size().to_frame('Number of Alt Fuel Facilities')
    dfnew = pd.merge(dfnew, alt1, how='left', on=['Name'])
    return(dfnew)

#Functino to add factories data
def FacSet(dfnew):
    # Import the facility pollution data set
    # Count the number of factories by state and add it to the master data set
    facpol = pd.read_csv('FacilityPollution.csv')
    # Conform state names
    facpol['Location'] = facpol['Location'].str.lower()
    facpol['Location'] = facpol['Location'].str.title()
    facpol = facpol.replace('District Of Columbia', 'District of Columbia')
    facpol = facpol.rename(columns={'Location': 'Name'})
    fp1 = facpol.groupby(['Name'], as_index = False).size().to_frame('Number of Factories')
    dfnew = pd.merge(dfnew, fp1, how='left', on=['Name'])
    return(dfnew)

#Function to add temperature data
def TempSet(dfnew):
    # Read in temperature data that contains full list of lat-longs
    temps_old = pd.read_csv("temps_old.csv")
    
    # Save full list of coordinates
    geos_old = temps_old[['lat','long']]
    geos_old = geos_old.drop_duplicates()
    states = []
    
    ## This section pairs the full list of states with the full lat-long list
        
    # Save full state list back into Python variable
    with open('states.csv', 'r') as f:
      reader = csv.reader(f)
      statelist = list(reader)
    
    # Convert list to array to enable its orientation to be flipped from row to column
    statelist = np.array(statelist)
    # Flip array to column
    statelist = statelist.reshape(-1, 1)
    # Remove null value that ensued from flip
    statelist = statelist[statelist != '']
    
    # Add column of corresponding state names into coordinates dataframe
    geos_old["Name"] = statelist
    
    ## This section pairs the lat-long list we are actually using with its corresponding states list
    
    # Read in temperature data that we are actually using
    temps = pd.read_csv("temps2.csv")
    
    # Save list of states corresponding to coordinates we are actually using
    with open('statelist_final.csv', 'r') as f:
      reader = csv.reader(f)
      statelist_final = list(reader)
    
    # Convert list to array to enable its orientation to be flipped from row to column
    statelist_final = np.array(statelist_final)
    # Flip array to column
    statelist_final = statelist_final.reshape(-1, 1)
    # Remove null value that ensued from flip
    statelist_final = statelist_final[statelist_final != '']
    
    # Save coordinates of points we are actually using
    geos = temps[['lat','long']]
    geos = geos.drop_duplicates()
    
    # Merge full lat-long-state record with lat-long pairs we are using for analysis,
    # leaving only the lat-long-state sets we are actually using
    geoo = pd.merge(geos, geos_old, how='left', on=['lat','long'])
    geoo = geoo.dropna()
    
    # Add column of state names to coordinates we are using for analysis
    geoo['Name'] = statelist_final
    
    # Add state name column to temperatures dataframe
    temperatures = temps.merge(geoo, how = 'inner', on = ['lat', 'long'])
    
    # Define subset dataframe that contains only the numeric temperature data columns
    temp_sub = temperatures[['jan','apr','jul','oct']]
    # Calculate min, max, and mean for each year for each location. Don't include zero values
    # in consideration.
    temperatures['max'] = temp_sub[temp_sub!=0].max(axis=1)
    temperatures['min'] = temp_sub[temp_sub!=0].min(axis=1)
    temperatures['mean'] = temp_sub[temp_sub!=0].mean(axis=1)
    
    # Define lists of the unique years and state names in the dataset
    unique_states = temperatures['Name'].unique()
    unique_years = temperatures['year'].unique()
    
    # Columns that we will eventually add to master dataset
    columns = ['Name','Year','MinT','MaxT','MeanT']
    # Dataframe that we will merge with master dataset
    summary = pd.DataFrame(columns = columns)
    
    # For each state...
    for state in range(0,len(unique_states)):
        
        # Save dataframe that contains only the rows from this state
        matrix = temperatures[temperatures['Name'] == unique_states[state]]
        
        # For each year...
        for year in unique_years:
            
            # Define row that will store this row-year pair's data
            row = pd.DataFrame(columns = columns, index=[0])
            #Label row with state name and year
            row['Name'] = unique_states[state]
            row['Year'] = year
            
            # Define subset of this state's matrix that only contains rows from this year
            new = matrix[matrix['year']==year]
            
            # Calculate mean, min, and max
            row['MeanT'] = new['mean'].mean()
            row['MinT'] = new['min'].mean()
            row['MaxT'] = new['max'].mean()
        
            # Append row containing this state-year pair's state name, year, mean, min, and max
            summary = summary.append(row)
    
    # Merge with the master dataset by state and year
    dfnew = pd.merge(dfnew, summary, how='left', on=['Name', 'Year'])
    return(dfnew)

#Function to add forest data
def ForestSet(dfnew):
    # Import Forest Data
    Forest_Data = pd.read_csv('Forest_Data.csv') 
    
    # Drop region values
    Forest_Data = Forest_Data.rename(columns={'Region': 'Name'})
    Forest_Data = Forest_Data[Forest_Data.Name != 'Northeast Total       ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North total']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Southeast Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'South Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Northwest Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'South total']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Rocky Mountain total:']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Coast total:']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Intermountain Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'United States:     ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Great Plains Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Southwest Total        ']
    
    # reindex 
    Forest_Data = Forest_Data.reset_index(drop=True)
    # make all names matching
    for i in range(len(Forest_Data.Name)):
        Forest_Data.Name[i] = Forest_Data.Name[i].strip() 
        
    # drop years we aren't using
    Forest_Data = Forest_Data.drop(['1997b','1987b','1977b','1963b','1953b','1938b','1920b','1907b','1630c'], axis=1)
    dfnew["Forest Acreage(Thousands)"] =  np.nan
    
    for i in range(len(dfnew)): # loop through all rows of big dataframe
        for j in range(len(Forest_Data)): # loop through all rows of forest_data
            for k in range(3): # loop through columns of Forest_data
                p = k+1 
                if (str(dfnew.Year[i]) == Forest_Data.columns[p] and dfnew.Name[i] == Forest_Data.iloc[j,0]):
                    dfnew["Forest Acreage(Thousands)"][i] = Forest_Data.iloc[j,p]
    
    
    # Convert ints and floats improperly saved as strings to numeric variables
    for i in range(0,len(dfnew)):
        dfnew['Percent increase in urban land 2000-2010'][i] = float(dfnew['Percent increase in urban land 2000-2010'][i])

        if type(dfnew['Forest Acreage(Thousands)'][i]) == str:
            dfnew['Forest Acreage(Thousands)'][i] = dfnew['Forest Acreage(Thousands)'][i].replace(',','')
            dfnew['Forest Acreage(Thousands)'][i] = int(dfnew['Forest Acreage(Thousands)'][i])
    return(dfnew)

#Function to create temp difference
def MaxMinTinc(dfnew):
    dfnew['MaxTInc'] = np.nan
    dfnew['MinTInc'] = np.nan
    # Calculate new columns' values for years for which we have previous year's data (i.e. all except 2000)
    # For each row...
    for row in range(0,len(dfnew)):
        # Save off state and year
        state = dfnew['Name'][row]
        year = dfnew['Year'][row]
        # Find row that is same state but in previous year
        plus = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year-1)]
        #Calculate difference between this year's max temp and previous year's max and min temp
        maxTplus = dfnew['MaxT'][row] - plus['MaxT']
        minTplus = dfnew['MinT'][row] - plus['MinT']

    
        # Avoid erroring by skipping if previous year's values didn't exist
        if maxTplus.empty == False:
            # Otherwise, add to temp change column
            dfnew['MinTInc'][row] = minTplus.values[0]
            # Avoid erroring by skipping if previous year's values didn't exist
        if maxTplus.empty == False:
            # Otherwise, add to temp change column
            dfnew['MaxTInc'][row] = maxTplus.values[0]      
    
    return(dfnew)
        
# This function creates a dataset that computes differences in each attribute between 2010 and 2000 by state
# These data are used for urbanization analyses
def UrbData(dfnew):
    df1 = dfnew[dfnew.Year == 2000] #take a portion of the data for 2000
    df2 = dfnew[dfnew.Year == 2010] #take a portion of the data for 2010
    #Merge the data together on attributes of interest
    df3 = pd.merge(df1,df2[['Name','Population', 'Passenger Trips','Operating Expenses FY',
            'MinT', 'MaxT', 'MeanT']], on = 'Name', how='left')
    #Loop through the columns and calcualte difference for each attribute
    cols = ['Population', 'Passenger Trips','Operating Expenses FY',
            'MinT', 'MaxT', 'MeanT']
    for col in cols:
        name1 = str(col)+'_x'
        name2 = str(col)+'_y'
        df3[col] = df3[name2] - df3[name1]
        df3 = df3.drop(columns = [name1,name2])
        df3[col] = pd.to_numeric(df3[col]) #make sure the value is numeric
    #Subset just the columns of interest
    df3 = df3[['MaxT','MinT', 'MeanT', 'Percent increase in urban land 2000-2010', 'Population', 'Name', 'Automobiles', 'Buses', 'Trucks', 'Motorcycles', 'Large Airport', 'Medium Airport', 'Small Airport' ]]
    df3['Percent increase in urban land 2000-2010'] = pd.to_numeric(df3['Percent increase in urban land 2000-2010'])
    df3['Population'] = df3['Population']/10000
    df3 = df3.dropna(subset=['Percent increase in urban land 2000-2010']) #drop any rows where urban land data are missing
    df3 = df3.fillna(0) #fill emply cells with 0
    return(df3)

###### Graphs #######


def BarG1(dfnew):
    fig = px.bar(dfnew, x='Name', y='MaxT', color="Name",
      animation_frame='Year', animation_group="Name", range_y=[0,35])
    fig.show()
    py.plot(fig, filename='2014 Forest Land Per Capita by Country.html')


### South and North Graphic
def MaxSouthNorthTime(dfnew):
    NorthStates = dfnew[dfnew['Name'].isin(['Alaska', 'Connecticut','Idaho','Illinois','Indiana','Iowa','Maine','Massachusetts','Michigan','Minnesota',
                                  'Montana','Nebraska','New Hampshire','New Jersey','New York','North Dakota','Ohio','Oregon','Pennsylvania','Rhode Island'
                                  'South Dakota','Vermont','Washington','Wisconsin','Wyoming'])]
    SouthStates = dfnew[dfnew['Name'].isin(['Alabama','Arizona','Arkansas','California','Colorado','Delaware','District of Columbia','Florida',
                                  'Georgia','Hawaii','Kansas','Kentucky','Louisiana','Mississippi','Missouri','Nevada','New Mexico','North Carolina','Oklahoma',
                                  'South Carolina','Tennessee','Texas','Utah','Virginia','West Virginia', 'Maryland'])]
        
    NorthStates = pd.DataFrame(NorthStates)
    SouthStates = pd.DataFrame(SouthStates)
    
    a = NorthStates.groupby('Year',as_index = False).mean()
    a['Name'] = 'North'
    
    b = SouthStates.groupby('Year',as_index = False).mean()
    b['Name'] = 'South'
    
    ab = pd.concat([a,b])
    
    dfnew['Region'] = 'South'
    for state in set(dfnew.Name):
        if  state  in ['Alaska', 'Connecticut','Idaho','Illinois','Indiana','Iowa','Maine','Massachusetts','Michigan','Minnesota','Montana','Nebraska','New Hampshire','New Jersey','New York','North Dakota','Ohio','Oregon','Pennsylvania','Rhode Island','South Dakota','Vermont','Washington','Wisconsin','Wyoming']:
            dfnew['Region'][dfnew.Name == state] = 'North'
    
    years = [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014]
    
    # make list of continents
    regions = ['South','North']
    
    # make figure
    fig_dict = {
        "data": [],
        "layout": {},
        "frames": []
    }
    
    # fill in most of layout
    fig_dict["layout"]["xaxis"] = {"range": [-5, 35], "title": "Maximum Temperature"}
    fig_dict["layout"]["yaxis"] = {"title": "Car Registrations Per Capita"}
    fig_dict["layout"]["hovermode"] = "closest"
    fig_dict["layout"]["sliders"] = {
        "args": [
            "transition", {
                "duration": 400,
                "easing": "cubic-in-out"
            }
        ],
        "initialValue": "2000",
        "plotlycommand": "animate",
        "values": years,
        "visible": True
    }
    fig_dict["layout"]["updatemenus"] = [
        {
            "buttons": [
                {
                    "args": [None, {"frame": {"duration": 500, "redraw": False},
                                    "fromcurrent": True, "transition": {"duration": 300,
                                                                        "easing": "quadratic-in-out"}}],
                    "label": "Play",
                    "method": "animate"
                },
                {
                    "args": [[None], {"frame": {"duration": 0, "redraw": False},
                                      "mode": "immediate",
                                      "transition": {"duration": 0}}],
                    "label": "Pause",
                    "method": "animate"
                }
            ],
            "direction": "left",
            "pad": {"r": 10, "t": 87},
            "showactive": False,
            "type": "buttons",
            "x": 0.1,
            "xanchor": "right",
            "y": 0,
            "yanchor": "top"
        }
    ]
    
    sliders_dict = {
        "active": 0,
        "yanchor": "top",
        "xanchor": "left",
        "currentvalue": {
            "font": {"size": 20},
            "prefix": "Year:",
            "visible": True,
            "xanchor": "right"
        },
        "transition": {"duration": 350, "easing": "cubic-in-out"},
        "pad": {"b": 10, "t": 50},
        "len": 0.9,
        "x": 0.1,
        "y": 0,
        "steps": []
    }
    
    # make data
    year = 2000
    for region in regions:
        dataset_by_year = dfnew[dfnew["Year"] == year]
        dataset_by_year_and_cont = dataset_by_year[
            dataset_by_year["Region"] == region]
    
        data_dict = {
            "x": list(dataset_by_year_and_cont["MaxT"]),
            "y": list(dataset_by_year_and_cont["CarPC"]),
            "mode": "markers",
            "text": list(dataset_by_year_and_cont["Name"]),
            "name": region
        }
        fig_dict["data"].append(data_dict)
    
    # make frames
    for year in years:
        frame = {"data": [], "name": str(year)}
        for region in regions:
            dataset_by_year = dfnew[dfnew["Year"] == int(year)]
            dataset_by_year_and_cont = dataset_by_year[
                dataset_by_year["Region"] == region]
    
            data_dict = {
                "x": list(dataset_by_year_and_cont["MaxT"]),
                "y": list(dataset_by_year_and_cont["CarPC"]),
                "mode": "markers",
                "text": list(dataset_by_year_and_cont["Name"]),
                "name": region
            }
            frame["data"].append(data_dict)
    
        fig_dict["frames"].append(frame)
        slider_step = {"args": [
            [year],
            {"frame": {"duration": 300, "redraw": False},
             "mode": "immediate",
             "transition": {"duration": 300}}
        ],
            "label": year,
            "method": "animate"}
        sliders_dict["steps"].append(slider_step)
    
    
    fig_dict["layout"]["sliders"] = [sliders_dict]
    fig_dict['layout']['paper_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['plot_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['title']='Maximum Temperatures Over Time: South vs. North'
    
    fig = go.Figure(fig_dict)
    
    fig.show()
    py.plot(fig, filename='Maximum Temperatures by Region Over Time.html')

### South and North Graphic
def MinSouthNorthTime(dfnew):
    NorthStates = dfnew[dfnew['Name'].isin(['Alaska', 'Connecticut','Idaho','Illinois','Indiana','Iowa','Maine','Massachusetts','Michigan','Minnesota',
                                  'Montana','Nebraska','New Hampshire','New Jersey','New York','North Dakota','Ohio','Oregon','Pennsylvania','Rhode Island'
                                  'South Dakota','Vermont','Washington','Wisconsin','Wyoming'])]
    SouthStates = dfnew[dfnew['Name'].isin(['Alabama','Arizona','Arkansas','California','Colorado','Delaware','District of Columbia','Florida',
                                  'Georgia','Hawaii','Kansas','Kentucky','Louisiana','Mississippi','Missouri','Nevada','New Mexico','North Carolina','Oklahoma',
                                  'South Carolina','Tennessee','Texas','Utah','Virginia','West Virginia', 'Maryland'])]
        
    NorthStates = pd.DataFrame(NorthStates)
    SouthStates = pd.DataFrame(SouthStates)
    
    a = NorthStates.groupby('Year',as_index = False).mean()
    a['Name'] = 'North'
    
    b = SouthStates.groupby('Year',as_index = False).mean()
    b['Name'] = 'South'
    
    ab = pd.concat([a,b])
    
    dfnew['Region'] = 'South'
    for state in set(dfnew.Name):
        if  state  in ['Alaska', 'Connecticut','Idaho','Illinois','Indiana','Iowa','Maine','Massachusetts','Michigan','Minnesota','Montana','Nebraska','New Hampshire','New Jersey','New York','North Dakota','Ohio','Oregon','Pennsylvania','Rhode Island','South Dakota','Vermont','Washington','Wisconsin','Wyoming']:
            dfnew['Region'][dfnew.Name == state] = 'North'
    
    years = [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014]
    
    # make list of continents
    regions = ['South','North']
    
    # make figure
    fig_dict = {
        "data": [],
        "layout": {},
        "frames": []
    }
    
    # fill in most of layout
    fig_dict["layout"]["xaxis"] = {"range": [-15, 25], "title": "Minimum Temperature"}
    fig_dict["layout"]["yaxis"] = {"title": "Car Registrations Per Capita"}
    fig_dict["layout"]["hovermode"] = "closest"
    fig_dict["layout"]["sliders"] = {
        "args": [
            "transition", {
                "duration": 400,
                "easing": "cubic-in-out"
            }
        ],
        "initialValue": "2000",
        "plotlycommand": "animate",
        "values": years,
        "visible": True
    }
    fig_dict["layout"]["updatemenus"] = [
        {
            "buttons": [
                {
                    "args": [None, {"frame": {"duration": 500, "redraw": False},
                                    "fromcurrent": True, "transition": {"duration": 300,
                                                                        "easing": "quadratic-in-out"}}],
                    "label": "Play",
                    "method": "animate"
                },
                {
                    "args": [[None], {"frame": {"duration": 0, "redraw": False},
                                      "mode": "immediate",
                                      "transition": {"duration": 0}}],
                    "label": "Pause",
                    "method": "animate"
                }
            ],
            "direction": "left",
            "pad": {"r": 10, "t": 87},
            "showactive": False,
            "type": "buttons",
            "x": 0.1,
            "xanchor": "right",
            "y": 0,
            "yanchor": "top"
        }
    ]
    
    sliders_dict = {
        "active": 0,
        "yanchor": "top",
        "xanchor": "left",
        "currentvalue": {
            "font": {"size": 20},
            "prefix": "Year:",
            "visible": True,
            "xanchor": "right"
        },
        "transition": {"duration": 350, "easing": "cubic-in-out"},
        "pad": {"b": 10, "t": 50},
        "len": 0.9,
        "x": 0.1,
        "y": 0,
        "steps": []
    }
    
    # make data
    year = 2000
    for region in regions:
        dataset_by_year = dfnew[dfnew["Year"] == year]
        dataset_by_year_and_cont = dataset_by_year[
            dataset_by_year["Region"] == region]
    
        data_dict = {
            "x": list(dataset_by_year_and_cont["MinT"]),
            "y": list(dataset_by_year_and_cont["CarPC"]),
            "mode": "markers",
            "text": list(dataset_by_year_and_cont["Name"]),
            "name": region
        }
        fig_dict["data"].append(data_dict)
    
    # make frames
    for year in years:
        frame = {"data": [], "name": str(year)}
        for region in regions:
            dataset_by_year = dfnew[dfnew["Year"] == int(year)]
            dataset_by_year_and_cont = dataset_by_year[
                dataset_by_year["Region"] == region]
    
            data_dict = {
                "x": list(dataset_by_year_and_cont["MinT"]),
                "y": list(dataset_by_year_and_cont["CarPC"]),
                "mode": "markers",
                "text": list(dataset_by_year_and_cont["Name"]),
                "name": region
            }
            frame["data"].append(data_dict)
    
        fig_dict["frames"].append(frame)
        slider_step = {"args": [
            [year],
            {"frame": {"duration": 300, "redraw": False},
             "mode": "immediate",
             "transition": {"duration": 300}}
        ],
            "label": year,
            "method": "animate"}
        sliders_dict["steps"].append(slider_step)
    
    
    fig_dict["layout"]["sliders"] = [sliders_dict]
    fig_dict['layout']['paper_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['plot_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['title']='Minimum Temperatures Over Time: South vs. North'
    
    fig = go.Figure(fig_dict)
    
    fig.show()
    py.plot(fig, filename='Minimum Temperatures by Region Over Time.html')

    

# Urban land Graph
def UrbLanGraph(df3):
    df3 = df3.sort_values(by=['Percent increase in urban land 2000-2010'])
    ys = list(df3.Name)
    xs = list(df3['Percent increase in urban land 2000-2010'])
    
    fig = go.Figure([go.Bar(y=ys, 
                            x=xs,
                            marker_color='rgb(26, 118, 255)',
                            orientation='h')])
            
    fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', 
                      plot_bgcolor='rgba(0,0,0,0)', 
                      title = '2000-2010 Increase of Urban Land',
                      yaxis_tickfont_size=8,
                      xaxis=dict(
                        title='Urban Land Increase (%)',
                        titlefont_size=10,
                        tickfont_size=10,),
                      bargap=0.2,)
    
    fig.show()
    py.plot(fig, filename='Urban Land Change by State.html')


#Histogram of urban land
def UrbLanHist(df3):
    fig = go.Figure(data=[go.Histogram(x=df3['Percent increase in urban land 2000-2010'], histnorm='probability')])
    fig.update_layout(title = 'Distribution of Urban Land Increase')
    fig.show()
    py.plot(fig, filename='Urban Land Change Distribution.html')
    


#Bar Chart of Airports By State
def AirportLand(df3):
    df3 = df3.sort_values(by=['Large Airport'])
    
    fig = go.Figure(data=[
        go.Bar(name='Large Airports', x=df3.Name, y=df3['Large Airport']),
        go.Bar(name='Medium Airports', x=df3.Name, y=df3['Medium Airport']),
        go.Bar(name='Small Airports', x=df3.Name, y=df3['Small Airport'])
    ])
    # Change the bar mode
    fig.update_layout(barmode='stack',
                      paper_bgcolor='rgba(0,0,0,0)', 
                      plot_bgcolor='rgba(0,0,0,0)',
                      title = 'Number of Airports by State')
    fig.show()
    py.plot(fig, filename='Number of Airports by State.html')

def EVGraph():
    evreg = pd.read_csv('EV_Registrations_by_Type_US_by_Year.csv')
    evreg = evreg.drop(columns=['Unnamed: 0','Unnamed: 0.1'])
    evreg = evreg.replace('U',0) #replace empty values with 0s 
    colev = evreg.columns
    
    a = pd.DataFrame(columns=['Year', 'Hybrid', 'PlugHybrid', 'Electric'])
    # Add a column of total values by state by year 
    temp = []
    for col in colev:
            temp.append(int(col))
    a['Year'] = temp
    for col in colev:    
        a['Hybrid'].mask(a['Year']== int(col), evreg[col][0], inplace=True)
        a['PlugHybrid'].mask(a['Year']== int(col), evreg[col][1], inplace=True)
        a['Electric'].mask(a['Year']== int(col), evreg[col][2], inplace=True)
        
    
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=a.Year, y=a.Hybrid,
                        mode='lines',
                        name='Hybrid Vehicles'))
    fig.add_trace(go.Scatter(x=a.Year, y=a.PlugHybrid,
                        mode='lines',
                        name='Plug-Hybrid Vehicles'))
    fig.add_trace(go.Scatter(x=a.Year, y=a.Electric,
                        mode='lines', name='Electric Vehicles'))
    fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', 
                      plot_bgcolor='rgba(0,0,0,0)',
                      title = 'Electric Vehicle Registrations Over Time',
                      xaxis = dict(
                        tickmode = 'linear',
                        tick0 = 2,
                        dtick = 2))
    fig.show()
    py.plot(fig, filename='Electric Vehicle Registrations Over Time.html')


# Max Tempeature by state over time graph
# Size of each bubble defined by population size
def MaxTempTime(dfnew):
    years = [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014]
    states = list(set(dfnew.Name))
    
    # make figure
    fig_dict = {
        "data": [],
        "layout": {},
        "frames": []
    }
    
    # fill in most of layout
    fig_dict["layout"]["xaxis"] = {"range": [-5, 35], "title": "Maximum Temperature"}
    fig_dict["layout"]["yaxis"] = {"title": "Car Registrations"}
    fig_dict["layout"]["hovermode"] = "closest"
    fig_dict["layout"]["sliders"] = {
        "args": [
            "transition", {
                "duration": 400,
                "easing": "cubic-in-out"
            }
        ],
        "initialValue": "2000",
        "plotlycommand": "animate",
        "values": years,
        "visible": True
    }
    fig_dict["layout"]["updatemenus"] = [
        {
            "buttons": [
                {
                    "args": [None, {"frame": {"duration": 500, "redraw": False},
                                    "fromcurrent": True, "transition": {"duration": 300,
                                                                        "easing": "quadratic-in-out"}}],
                    "label": "Play",
                    "method": "animate"
                },
                {
                    "args": [[None], {"frame": {"duration": 0, "redraw": False},
                                      "mode": "immediate",
                                      "transition": {"duration": 0}}],
                    "label": "Pause",
                    "method": "animate"
                }
            ],
            "direction": "left",
            "pad": {"r": 10, "t": 87},
            "showactive": False,
            "type": "buttons",
            "x": 0.1,
            "xanchor": "right",
            "y": 0,
            "yanchor": "top"
        }
    ]
    
    sliders_dict = {
        "active": 0,
        "yanchor": "top",
        "xanchor": "left",
        "currentvalue": {
            "font": {"size": 20},
            "prefix": "Year:",
            "visible": True,
            "xanchor": "right"
        },
        "transition": {"duration": 350, "easing": "cubic-in-out"},
        "pad": {"b": 10, "t": 50},
        "len": 0.9,
        "x": 0.1,
        "y": 0,
        "steps": []
    }
    
    # make data
    year = 2000
    for state in states:
        dataset_by_year = dfnew[dfnew["Year"] == year]
        dataset_by_year_and_cont = dataset_by_year[
            dataset_by_year["Name"] == state]
    
        data_dict = {
            "x": list(dataset_by_year_and_cont["MaxT"]),
            "y": list(dataset_by_year_and_cont["Automobiles"]),
            "mode": "markers",
            "text": list(dataset_by_year_and_cont["Name"]),
            "name": state,
            "marker": {
                    "sizeref": 500000,
                    "size": list(dataset_by_year_and_cont["Population"])
                }
        }
        fig_dict["data"].append(data_dict)
    
    # make frames
    for year in years:
        frame = {"data": [], "name": str(year)}
        for state in states:
            dataset_by_year = dfnew[dfnew["Year"] == int(year)]
            dataset_by_year_and_cont = dataset_by_year[
                dataset_by_year["Name"] == state]
    
            data_dict = {
                "x": list(dataset_by_year_and_cont["MaxT"]),
                "y": list(dataset_by_year_and_cont["Automobiles"]),
                "mode": "markers",
                "text": list(dataset_by_year_and_cont["Name"]),
                "name": state,
                "marker": {
                    "sizeref": 500000,
                    "size": list(dataset_by_year_and_cont["Population"])
                }
            }
            frame["data"].append(data_dict)
    
        fig_dict["frames"].append(frame)
        slider_step = {"args": [
            [year],
            {"frame": {"duration": 300, "redraw": False},
             "mode": "immediate",
             "transition": {"duration": 300}}
        ],
            "label": year,
            "method": "animate"}
        sliders_dict["steps"].append(slider_step)
    
    
    fig_dict["layout"]["sliders"] = [sliders_dict]
    
    fig_dict['layout']['paper_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['plot_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['title']='Maximum Temperatures Over Time'
    
    fig = go.Figure(fig_dict)
    
    fig.show()
    py.plot(fig, filename='Maximum Temperatures Over Time.html')

# Min Tempeature by state over time graph
# Size of each bubble defined by population size
def MinTempTime(dfnew):
    years = [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014]
    states = list(set(dfnew.Name))
    
    # make figure
    fig_dict = {
        "data": [],
        "layout": {},
        "frames": []
    }
    
    # fill in most of layout
    fig_dict["layout"]["xaxis"] = {"range": [-15, 25], "title": "Maximum Temperature"}
    fig_dict["layout"]["yaxis"] = {"title": "Car Registrations"}
    fig_dict["layout"]["hovermode"] = "closest"
    fig_dict["layout"]["sliders"] = {
        "args": [
            "transition", {
                "duration": 400,
                "easing": "cubic-in-out"
            }
        ],
        "initialValue": "2000",
        "plotlycommand": "animate",
        "values": years,
        "visible": True
    }
    fig_dict["layout"]["updatemenus"] = [
        {
            "buttons": [
                {
                    "args": [None, {"frame": {"duration": 500, "redraw": False},
                                    "fromcurrent": True, "transition": {"duration": 300,
                                                                        "easing": "quadratic-in-out"}}],
                    "label": "Play",
                    "method": "animate"
                },
                {
                    "args": [[None], {"frame": {"duration": 0, "redraw": False},
                                      "mode": "immediate",
                                      "transition": {"duration": 0}}],
                    "label": "Pause",
                    "method": "animate"
                }
            ],
            "direction": "left",
            "pad": {"r": 10, "t": 87},
            "showactive": False,
            "type": "buttons",
            "x": 0.1,
            "xanchor": "right",
            "y": 0,
            "yanchor": "top"
        }
    ]
    
    sliders_dict = {
        "active": 0,
        "yanchor": "top",
        "xanchor": "left",
        "currentvalue": {
            "font": {"size": 20},
            "prefix": "Year:",
            "visible": True,
            "xanchor": "right"
        },
        "transition": {"duration": 350, "easing": "cubic-in-out"},
        "pad": {"b": 10, "t": 50},
        "len": 0.9,
        "x": 0.1,
        "y": 0,
        "steps": []
    }
    
    # make data
    year = 2000
    for state in states:
        dataset_by_year = dfnew[dfnew["Year"] == year]
        dataset_by_year_and_cont = dataset_by_year[
            dataset_by_year["Name"] == state]
    
        data_dict = {
            "x": list(dataset_by_year_and_cont["MinT"]),
            "y": list(dataset_by_year_and_cont["Automobiles"]),
            "mode": "markers",
            "text": list(dataset_by_year_and_cont["Name"]),
            "name": state,
            "marker": {
                    "sizeref": 500000,
                    "size": list(dataset_by_year_and_cont["Population"])
                }
        }
        fig_dict["data"].append(data_dict)
    
    # make frames
    for year in years:
        frame = {"data": [], "name": str(year)}
        for state in states:
            dataset_by_year = dfnew[dfnew["Year"] == int(year)]
            dataset_by_year_and_cont = dataset_by_year[
                dataset_by_year["Name"] == state]
    
            data_dict = {
                "x": list(dataset_by_year_and_cont["MinT"]),
                "y": list(dataset_by_year_and_cont["Automobiles"]),
                "mode": "markers",
                "text": list(dataset_by_year_and_cont["Name"]),
                "name": state,
                "marker": {
                    "sizeref": 500000,
                    "size": list(dataset_by_year_and_cont["Population"])
                }
            }
            frame["data"].append(data_dict)
    
        fig_dict["frames"].append(frame)
        slider_step = {"args": [
            [year],
            {"frame": {"duration": 300, "redraw": False},
             "mode": "immediate",
             "transition": {"duration": 300}}
        ],
            "label": year,
            "method": "animate"}
        sliders_dict["steps"].append(slider_step)
    
    
    fig_dict["layout"]["sliders"] = [sliders_dict]
    
    fig_dict['layout']['paper_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['plot_bgcolor']='rgba(0,0,0,0)'
    fig_dict['layout']['title']='Minimum Temperatures Over Time'
    
    fig = go.Figure(fig_dict)
    
    fig.show()
    py.plot(fig, filename='Minimum Temperatures Over Time.html')




if __name__ == '__main__':
    Main()
