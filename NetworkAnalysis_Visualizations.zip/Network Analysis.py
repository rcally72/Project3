#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 08:57:55 2019

@author: mashagubenko
"""
import pandas as pd
import csv
import numpy as np

import networkx as nx

def Main():
    dfnew = MasterDataSet() #create master dataset 
    dfnew = BinData(dfnew) #make the variables of interest binary to create a bipartite graph 
    
    #Part 1 Network Analysis
    #Make graph for every variable for every year
    #loop through the variables and the years
    for var in ['CarPCV',  'BusPCV', 'TruckPCV', 'MaxC']: 
        for i in [2001,2005,2010,2014]:
            A = MakeGraph(dfnew, var, i, 1)
            msg = 'Graph metrics for ' + str(var) + ' '+ str(i)
            print()
            print(msg)
            GraphMetrics(A) #graph metrics
            GraphYear(A) #plot of the graph
            #Clustering 
            ModCluster(A)
            BetweenCluster(A)
            
    #Part 2 Network Analysis
    #Make graph for the highest weighted edges for every year
    for i in [2001,2005,2010,2014]:
        A = MakeGraphVar(dfnew,i)
        msg = 'Graph metrics for the highest wegithed edges for ' + str(i)
        print()
        print(msg)
        GraphMetrics(A) #graph metrics
        GraphYear(A) #plot of the graph
        #Clustering 
        ModCluster(A)
        BetweenCluster(A)
    
######### DATA PREPROCESSING ######################

# This function creates a master dataset of all our data 
def MasterDataSet():    
    new = PopSet() #calling a function to create a dataframe of population data
    dfnew = TransitSet(new) #calling a function to add transit data
    dfnew = VehRegSet(dfnew) #calling a function to add veh reg data    
    dfnew = ElecSet(dfnew)  #calling a function to add electric vehicle data
    dfnew = AirportSet(dfnew)  #calling a function to add airport data
    dfnew = RegSet(dfnew)  #calling a function to add regions data
    dfnew = UrbSet(dfnew)  #calling a function to add urban land data
    dfnew = AltFuelSet(dfnew) #calling a function to alt facilities data
    dfnew = FacSet(dfnew) #calling a function to factories data
    dfnew = TempSet(dfnew)  #calling a function to add temperature data
    dfnew = ForestSet(dfnew)  #calling a function to add forest data
    dfnew = MaxMinTinc(dfnew)  #calling a function to create temp difference 
    
    dfnew['CarPC'] = dfnew['Automobiles']/dfnew.Population #creating a car per capita variable
    dfnew['TruckPC'] = dfnew['Trucks']/dfnew.Population #creating a truck per capita variable
    dfnew['BusPC'] = dfnew['Buses']/dfnew.Population  #creating a bus per capita variable
    dfnew['MCPC'] = dfnew['Motorcycles']/dfnew.Population #creating a motorcycle per capita variable
    dfnew['LAPC'] = dfnew['Large Airport']/dfnew.Population #creating a large airport per capita variable
    dfnew['MAPC'] = dfnew['Medium Airport']/dfnew.Population #creating a med airport per capita variable
    dfnew['SAPC'] = dfnew['Small Airport']/dfnew.Population #creating a small airport per capita variable
    
    return(dfnew) #return the final dataframe

#Functino to read in popuation data
def PopSet():
    # Start the master data set by setting a dataframe of all states' 
    # populations by year 
    # Import the population info by State
    popstate = pd.read_csv('Population_by_State_by_Year_2000_2010.csv')
    popstate = popstate.drop(columns=['Unnamed: 0','census2010pop','estimatesbase2000'])
    colpop = popstate.columns
    
    new = pd.DataFrame(columns=['Name', 'Population', 'Year'])
    # Loop through every column and add it as time series information for each state
    for col in colpop[1:len(colpop)]:
        df = popstate[['name',col]]
        df = df.groupby('name',as_index=False).max()
        df = df.rename(columns={col: 'Population', 'name':'Name'})
        df['Year'] = int(col[len(col)-4:len(col)])
        new = pd.concat([new,df],ignore_index=True) #combine the dataframes into one of all years
        
    # Import the population info by State part 2
    popstate = pd.read_csv('nst-est2018-alldata.csv')
    # Loop through every column and add it as time series information for each state
    popstate = popstate[['NAME', 'POPESTIMATE2011',
           'POPESTIMATE2012', 'POPESTIMATE2013', 'POPESTIMATE2014',
           'POPESTIMATE2015', 'POPESTIMATE2016', 'POPESTIMATE2017',
           'POPESTIMATE2018']]
    popstate = popstate.drop(popstate.index[[0,1,2,3,4]])
    colpop = popstate.columns
    
    new2 = pd.DataFrame(columns=['Name', 'Population', 'Year'])
    for col in colpop[1:len(colpop)]:
        df = popstate[['NAME',col]]
        df = df.groupby('NAME',as_index=False).max()
        df = df.rename(columns={col: 'Population', 'NAME':'Name'})
        df['Year'] = int(col[len(col)-4:len(col)])
        new2 = pd.concat([new2,df],ignore_index=True) #combine the dataframes into one of all years
    
    # Combine the two parts of population datasets into one
    new = pd.concat([new,new2],ignore_index=True)    
    
    return(new)

#Function to read in transit data
def TransitSet(new):
    # List of all states to change abbreviations to full names
    states = {
            'AK': 'Alaska',
            'AL': 'Alabama',
            'AR': 'Arkansas',
            'AS': 'American Samoa',
            'AZ': 'Arizona',
            'CA': 'California',
            'CO': 'Colorado',
            'CT': 'Connecticut',
            'DC': 'District of Columbia',
            'DE': 'Delaware',
            'FL': 'Florida',
            'GA': 'Georgia',
            'GU': 'Guam',
            'HI': 'Hawaii',
            'IA': 'Iowa',
            'ID': 'Idaho',
            'IL': 'Illinois',
            'IN': 'Indiana',
            'KS': 'Kansas',
            'KY': 'Kentucky',
            'LA': 'Louisiana',
            'MA': 'Massachusetts',
            'MD': 'Maryland',
            'ME': 'Maine',
            'MI': 'Michigan',
            'MN': 'Minnesota',
            'MO': 'Missouri',
            'MP': 'Northern Mariana Islands',
            'MS': 'Mississippi',
            'MT': 'Montana',
            'NA': 'National',
            'NC': 'North Carolina',
            'ND': 'North Dakota',
            'NE': 'Nebraska',
            'NH': 'New Hampshire',
            'NJ': 'New Jersey',
            'NM': 'New Mexico',
            'NV': 'Nevada',
            'NY': 'New York',
            'OH': 'Ohio',
            'OK': 'Oklahoma',
            'OR': 'Oregon',
            'PA': 'Pennsylvania',
            'PR': 'Puerto Rico',
            'RI': 'Rhode Island',
            'SC': 'South Carolina',
            'SD': 'South Dakota',
            'TN': 'Tennessee',
            'TX': 'Texas',
            'UT': 'Utah',
            'VA': 'Virginia',
            'VI': 'Virgin Islands',
            'VT': 'Vermont',
            'WA': 'Washington',
            'WI': 'Wisconsin',
            'WV': 'West Virginia',
            'WY': 'Wyoming'
    }
    
    
    # Import the transit data
    # Annual
    # Years 2002 - 2017 (most data for 2017)
    # Location as Lat/Long and City Name
    # Add to the master data set each piece of info from the transit data set by state by year 
    transit = pd.read_csv('TransitwithLatLong.csv')
    stat = transit['HQ State'].apply(lambda x: states[x]) #create a list of all states
    transit['HQ State'] = stat #add a column of all states
    #Total trips by state by year
    a = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Unlinked Passenger Trips FY'].sum()
    a = a.rename(columns={'FY End Year': 'Year', 'HQ State':'Name', 'Unlinked Passenger Trips FY': 'Passenger Trips'})
    #Largest service area by state by year
    b = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Service Area SQ Miles'].max()
    b = b.rename(columns={'FY End Year': 'Year', 'HQ State':'Name', 'Service Area SQ Miles': 'Largest Transit Service Area'})
    #Total trips by state by year
    c = transit.groupby(['HQ State', 'FY End Year'], as_index = False)['Operating Expenses FY'].sum()
    c = c.rename(columns={'FY End Year': 'Year', 'HQ State':'Name'})
    
    # Add transit info to the master dataframe by state and year
    dfnew = pd.merge(new, a, how='left', on=['Name', 'Year'])
    dfnew = pd.merge(dfnew, b, how='left', on=['Name', 'Year'])
    dfnew = pd.merge(dfnew, c, how='left', on=['Name', 'Year'])
    
    return(dfnew)

#Function to add vehicle reg data    
def VehRegSet(dfnew):
    # Import the vehicle registration data
    # Annual by State
    # Location as state
    # Years 1995 - 2014
    # Add the data to the master dataset by state by year 
    vehreg = pd.read_csv('Vehicle_Registration_By_State_By_Year.csv')
    vehreg = vehreg.drop(columns=['Unnamed: 0', 'index'])
    vehreg = vehreg.rename(columns = {'State': 'Name', 'Motorcicles': 'Motorcycles'})
    # Conform state names
    vehreg.Name = vehreg.Name.str.replace(r'[\(\)\d]+', '')
    vehreg.Name = vehreg.Name.str.replace('/','')
    vehreg = vehreg.replace('Dist. of Col.', 'District of Columbia')
    
    # Clean the state names information for state names neding in ' ' or '  '
    for k in vehreg.Name:
        if k[len(k)-1] == ' ':
            if k[len(k)-2] == ' ':
                vehreg = vehreg.replace(k, k[0:len(k)-2])
            else:
                vehreg = vehreg.replace(k, k[0:len(k)-1])
                
    # Add to the master dataframe by state and year
    dfnew = pd.merge(dfnew, vehreg, how='left', on=['Name', 'Year'])
    for col in ['Automobiles', 'Buses', 'Trucks','Motorcycles']:
        dfnew[col] = dfnew[col]
    return(dfnew)

#Functino to add electric vehicle data
def ElecSet(dfnew):
    # Import the data set on electric vehicle registrations 
    # Annual 
    # Aggregated for the entire country by vehicle type & year so location is US
    # Years: 1999-2017
    evreg = pd.read_csv('EV_Registrations_by_Type_US_by_Year.csv')
    evreg = evreg.drop(columns=['Unnamed: 0','Unnamed: 0.1'])
    evreg = evreg.replace('U',0) #replace empty values with 0s 
    colev = evreg.columns
    
    # Add the ev registration data to the master dataset
    # Total number of ev registrations in the US is added to each state for each type of ev
    dfnew['Hybrid'] = 0 
    dfnew['PlugHybrid'] = 0 
    dfnew['Electric'] = 0 
    # Add a column of total values by state by year 
    for col in colev:
        dfnew['Hybrid'].mask(dfnew['Year']== int(col), evreg[col][0], inplace=True)
        dfnew['PlugHybrid'].mask(dfnew['Year']== int(col), evreg[col][1], inplace=True)
        dfnew['Electric'].mask(dfnew['Year']== int(col), evreg[col][2], inplace=True)
    
    # Estimate state level values by dividing the country totals by population 
    dfnew['Hybrid'] = pd.to_numeric(dfnew['Hybrid'])
    dfnew['PlugHybrid'] = pd.to_numeric(dfnew['PlugHybrid'])
    dfnew['Electric'] = pd.to_numeric(dfnew['Electric'])
    dfnew['Hybrid'] = dfnew['Hybrid']/dfnew['Population']
    dfnew['PlugHybrid'] = dfnew['PlugHybrid']/dfnew['Population']
    dfnew['Electric'] = dfnew['Electric']/dfnew['Population']
    return(dfnew)

#Function to add airport data    
def AirportSet(dfnew):
    # Import the data on airport location
    # Add number of airports by type by state to the master dataset
    airloc = pd.read_csv('AirportLocation.csv') 
    # Conform state names
    airloc['Location'] = airloc['Location'].str.lower()
    airloc['Location'] = airloc['Location'].str.title()
    airloc = airloc.replace('District Of Columbia', 'District of Columbia')
    airloc = airloc[airloc['type'] != 'closed'] #drop the rows where airports have been closed
    airloc = airloc.rename(columns={'Location': 'Name'})
    
    # Split into dataframes for each airport type
    a1 = airloc[airloc['type'] == 'balloonport']
    a2 = airloc[airloc['type'] == 'heliport']
    a3 = airloc[airloc['type'] == 'large_airport']
    a4 = airloc[airloc['type'] == 'medium_airport']
    a5 = airloc[airloc['type'] == 'seaplane_base']
    a6 = airloc[airloc['type'] == 'small_airport']
    
    # Aggregate the totals of each type of airprot by state by year 
    # And merge with the master data frame
    a11 = a1.groupby(['Name'], as_index = False).size().to_frame('Balloonport')
    dfnew = pd.merge(dfnew, a11, how='left', on=['Name'])
    a21 = a2.groupby(['Name'], as_index = False).size().to_frame('Heliport')
    dfnew = pd.merge(dfnew, a21, how='left', on=['Name'])
    a31 = a3.groupby(['Name'], as_index = False).size().to_frame('Large Airport')
    dfnew = pd.merge(dfnew, a31, how='left', on=['Name'])
    a41 = a4.groupby(['Name'], as_index = False).size().to_frame('Medium Airport')
    dfnew = pd.merge(dfnew, a41, how='left', on=['Name'])
    a51 = a5.groupby(['Name'], as_index = False).size().to_frame('Seaplane Base')
    dfnew = pd.merge(dfnew, a51, how='left', on=['Name'])
    a61 = a6.groupby(['Name'], as_index = False).size().to_frame('Small Airport')
    dfnew = pd.merge(dfnew, a61, how='left', on=['Name'])
    return(dfnew)

#Functino to add region data
def RegSet(dfnew):
    # Set up lists of states belonging to each region
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']    
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    # Set up columns corresponding to each of the region in the master dataset
    reg = ['NE','SE','PS','NC','SC','RM','GP','PN']
    for lst in reg:
        dfnew[lst] = 0
    
    # Loop through the lists of regions and identify states that belong to 
    # each region by assigning 1 to that column    
    reglist = [NE,SE,PS,NC,SC,RM,GP,PN]       
    i = 0 
    while i < len(reglist):  
        #print(reg[i])
        for j in range(0,len(dfnew['Name'])):
            if dfnew['Name'][j] in reglist[i]:
                dfnew[reg[i]][j] = 1
        i += 1
    return(dfnew)

#Function to add Urban Land data
def UrbSet(dfnew):
    # Set up lists of states belonging to each region
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']
    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']
    
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']
    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']
    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']
    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']
    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    # Set up columns corresponding to each of the region in the master dataset
    reg = ['NE','SE','PS','NC','SC','RM','GP','PN']
    # Import the urban land data set
    urbland = pd.read_csv('Urban_Land(2000-2010).csv') 
    urbland = urbland.drop(urbland.index[[0,9]]) # Drop totals
    
    # Pull the data from the urban data set on growth % of urban land by each region
    # Add the total % increase to each state belonging to the region in the master dataset    
    dfnew['Percent increase in urban land 2000-2010'] = 0
    for i in range(0, len(reg)-1):
        dfnew['Percent increase in urban land 2000-2010'].mask(dfnew[reg[i]] == 1, urbland['Percent increase in urban land 2000-2010'][i+1] , inplace=True)
    return(dfnew)

#Function to add alt fuel data
def AltFuelSet(dfnew):
    # Import the data set on alterantive fuel stations
    # Type of fuel by station information
    # Count the number of alterantive fuel facilities by state and add it to the master dataset
    altfuel = pd.read_csv('AlternativeFuelStationLocation.csv')
    # Conform state names
    altfuel['Location'] = altfuel['Location'].str.lower()
    altfuel['Location'] = altfuel['Location'].str.title()
    altfuel = altfuel.replace('District Of Columbia', 'District of Columbia')
    altfuel = altfuel.rename(columns={'Location': 'Name'})
    alt1 = altfuel.groupby(['Name'], as_index = False).size().to_frame('Number of Alt Fuel Facilities')
    dfnew = pd.merge(dfnew, alt1, how='left', on=['Name'])
    return(dfnew)

#Functino to add factories data
def FacSet(dfnew):
    # Import the facility pollution data set
    # Count the number of factories by state and add it to the master data set
    facpol = pd.read_csv('FacilityPollution.csv')
    # Conform state names
    facpol['Location'] = facpol['Location'].str.lower()
    facpol['Location'] = facpol['Location'].str.title()
    facpol = facpol.replace('District Of Columbia', 'District of Columbia')
    facpol = facpol.rename(columns={'Location': 'Name'})
    fp1 = facpol.groupby(['Name'], as_index = False).size().to_frame('Number of Factories')
    dfnew = pd.merge(dfnew, fp1, how='left', on=['Name'])
    return(dfnew)

#Function to add temperature data
def TempSet(dfnew):
    # Read in temperature data that contains full list of lat-longs
    temps_old = pd.read_csv("temps_old.csv")
    
    # Save full list of coordinates
    geos_old = temps_old[['lat','long']]
    geos_old = geos_old.drop_duplicates()
    states = []
    
    ## This section pairs the full list of states with the full lat-long list
        
    # Save full state list back into Python variable
    with open('states.csv', 'r') as f:
      reader = csv.reader(f)
      statelist = list(reader)
    
    # Convert list to array to enable its orientation to be flipped from row to column
    statelist = np.array(statelist)
    # Flip array to column
    statelist = statelist.reshape(-1, 1)
    # Remove null value that ensued from flip
    statelist = statelist[statelist != '']
    
    # Add column of corresponding state names into coordinates dataframe
    geos_old["Name"] = statelist
    
    ## This section pairs the lat-long list we are actually using with its corresponding states list
    
    # Read in temperature data that we are actually using
    temps = pd.read_csv("temps2.csv")
    
    # Save list of states corresponding to coordinates we are actually using
    with open('statelist_final.csv', 'r') as f:
      reader = csv.reader(f)
      statelist_final = list(reader)
    
    # Convert list to array to enable its orientation to be flipped from row to column
    statelist_final = np.array(statelist_final)
    # Flip array to column
    statelist_final = statelist_final.reshape(-1, 1)
    # Remove null value that ensued from flip
    statelist_final = statelist_final[statelist_final != '']
    
    # Save coordinates of points we are actually using
    geos = temps[['lat','long']]
    geos = geos.drop_duplicates()
    
    # Merge full lat-long-state record with lat-long pairs we are using for analysis,
    # leaving only the lat-long-state sets we are actually using
    geoo = pd.merge(geos, geos_old, how='left', on=['lat','long'])
    geoo = geoo.dropna()
    
    # Add column of state names to coordinates we are using for analysis
    geoo['Name'] = statelist_final
    
    # Add state name column to temperatures dataframe
    temperatures = temps.merge(geoo, how = 'inner', on = ['lat', 'long'])
    
    # Define subset dataframe that contains only the numeric temperature data columns
    temp_sub = temperatures[['jan','apr','jul','oct']]
    # Calculate min, max, and mean for each year for each location. Don't include zero values
    # in consideration.
    temperatures['max'] = temp_sub[temp_sub!=0].max(axis=1)
    temperatures['min'] = temp_sub[temp_sub!=0].min(axis=1)
    temperatures['mean'] = temp_sub[temp_sub!=0].mean(axis=1)
    
    # Define lists of the unique years and state names in the dataset
    unique_states = temperatures['Name'].unique()
    unique_years = temperatures['year'].unique()
    
    # Columns that we will eventually add to master dataset
    columns = ['Name','Year','MinT','MaxT','MeanT']
    # Dataframe that we will merge with master dataset
    summary = pd.DataFrame(columns = columns)
    
    # For each state...
    for state in range(0,len(unique_states)):
        
        # Save dataframe that contains only the rows from this state
        matrix = temperatures[temperatures['Name'] == unique_states[state]]
        
        # For each year...
        for year in unique_years:
            
            # Define row that will store this row-year pair's data
            row = pd.DataFrame(columns = columns, index=[0])
            #Label row with state name and year
            row['Name'] = unique_states[state]
            row['Year'] = year
            
            # Define subset of this state's matrix that only contains rows from this year
            new = matrix[matrix['year']==year]
            
            # Calculate mean, min, and max
            row['MeanT'] = new['mean'].mean()
            row['MinT'] = new['min'].mean()
            row['MaxT'] = new['max'].mean()
        
            # Append row containing this state-year pair's state name, year, mean, min, and max
            summary = summary.append(row)
    
    # Merge with the master dataset by state and year
    dfnew = pd.merge(dfnew, summary, how='left', on=['Name', 'Year'])
    return(dfnew)

#Function to add forest data
def ForestSet(dfnew):
    # Import Forest Data
    Forest_Data = pd.read_csv('Forest_Data.csv') 
    
    # Drop region values
    Forest_Data = Forest_Data.rename(columns={'Region': 'Name'})
    Forest_Data = Forest_Data[Forest_Data.Name != 'Northeast Total       ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'North total']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Southeast Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'South Central Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Northwest Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'South total']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Rocky Mountain total:']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Coast total:']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Intermountain Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'United States:     ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Great Plains Total        ']
    Forest_Data = Forest_Data[Forest_Data.Name != 'Pacific Southwest Total        ']
    
    # reindex 
    Forest_Data = Forest_Data.reset_index(drop=True)
    # make all names matching
    for i in range(len(Forest_Data.Name)):
        Forest_Data.Name[i] = Forest_Data.Name[i].strip() 
        
    # drop years we aren't using
    Forest_Data = Forest_Data.drop(['1997b','1987b','1977b','1963b','1953b','1938b','1920b','1907b','1630c'], axis=1)
    dfnew["Forest Acreage(Thousands)"] =  np.nan
    
    for i in range(len(dfnew)): # loop through all rows of big dataframe
        for j in range(len(Forest_Data)): # loop through all rows of forest_data
            for k in range(3): # loop through columns of Forest_data
                p = k+1 
                if (str(dfnew.Year[i]) == Forest_Data.columns[p] and dfnew.Name[i] == Forest_Data.iloc[j,0]):
                    dfnew["Forest Acreage(Thousands)"][i] = Forest_Data.iloc[j,p]
    
    
    # Convert ints and floats improperly saved as strings to numeric variables
    for i in range(0,len(dfnew)):
        dfnew['Percent increase in urban land 2000-2010'][i] = float(dfnew['Percent increase in urban land 2000-2010'][i])

        if type(dfnew['Forest Acreage(Thousands)'][i]) == str:
            dfnew['Forest Acreage(Thousands)'][i] = dfnew['Forest Acreage(Thousands)'][i].replace(',','')
            dfnew['Forest Acreage(Thousands)'][i] = int(dfnew['Forest Acreage(Thousands)'][i])
    return(dfnew)

#Function to create temp difference
def MaxMinTinc(dfnew):
    dfnew['MaxTInc'] = np.nan
    dfnew['MinTInc'] = np.nan
    # Calculate new columns' values for years for which we have previous year's data (i.e. all except 2000)
    # For each row...
    for row in range(0,len(dfnew)):
        # Save off state and year
        state = dfnew['Name'][row]
        year = dfnew['Year'][row]
        # Find row that is same state but in previous year
        plus = dfnew[(dfnew['Name'] == state) & (dfnew['Year'] == year-1)]
        #Calculate difference between this year's max temp and previous year's max and min temp
        maxTplus = dfnew['MaxT'][row] - plus['MaxT']
        minTplus = dfnew['MinT'][row] - plus['MinT']

    
        # Avoid erroring by skipping if previous year's values didn't exist
        if maxTplus.empty == False:
            # Otherwise, add to temp change column
            dfnew['MinTInc'][row] = minTplus.values[0]
            # Avoid erroring by skipping if previous year's values didn't exist
        if maxTplus.empty == False:
            # Otherwise, add to temp change column
            dfnew['MaxTInc'][row] = maxTplus.values[0]      
    
    return(dfnew)
        
# This function creates a dataset that computes differences in each attribute between 2010 and 2000 by state
# These data are used for urbanization analyses
def UrbData(dfnew):
    df1 = dfnew[dfnew.Year == 2000] #take a portion of the data for 2000
    df2 = dfnew[dfnew.Year == 2010] #take a portion of the data for 2010
    #Merge the data together on attributes of interest
    df3 = pd.merge(df1,df2[['Name','Population', 'Passenger Trips','Operating Expenses FY',
            'MinT', 'MaxT', 'MeanT']], on = 'Name', how='left')
    #Loop through the columns and calcualte difference for each attribute
    cols = ['Population', 'Passenger Trips','Operating Expenses FY',
            'MinT', 'MaxT', 'MeanT']
    for col in cols:
        name1 = str(col)+'_x'
        name2 = str(col)+'_y'
        df3[col] = df3[name2] - df3[name1]
        df3 = df3.drop(columns = [name1,name2])
        df3[col] = pd.to_numeric(df3[col]) #make sure the value is numeric
    #Subset just the columns of interest
    df3 = df3[['MaxT','MinT', 'MeanT', 'Percent increase in urban land 2000-2010', 'Population', 'Name', 'Automobiles', 'Buses', 'Trucks', 'Motorcycles', 'Large Airport', 'Medium Airport', 'Small Airport' ]]
    df3['Percent increase in urban land 2000-2010'] = pd.to_numeric(df3['Percent increase in urban land 2000-2010'])
    df3['Population'] = df3['Population']/10000
    df3 = df3.dropna(subset=['Percent increase in urban land 2000-2010']) #drop any rows where urban land data are missing
    df3 = df3.fillna(0) #fill emply cells with 0
    return(df3)

#Function to bin the important variables into binary to use for clustering analysis
def BinData(dfnew):
    dfnew['CarPCV'] = 0.25
    for i in range(0,dfnew.shape[0]):
        if dfnew.CarPC[i] >= 0.481:
            dfnew.CarPCV[i] = 1
        elif dfnew.CarPC[i] >= 0.434:
            dfnew.CarPCV[i] = 0.75
        elif dfnew.CarPC[i] >= 0.372:
            dfnew.CarPCV[i] = 0.5
    
    dfnew['TruckPCV'] = 0.25
    for i in range(0,dfnew.shape[0]):
        if dfnew.TruckPC[i] >= 0.319:
            dfnew.TruckPCV[i] = 1
        elif dfnew.TruckPC[i] >= 0.00965:
            dfnew.TruckPCV[i] = 0.75
        elif dfnew.TruckPC[i] >= 0.0061:
            dfnew.TruckPCV[i] = 0.5
                
    dfnew['BusPCV'] = 0.25
    for i in range(0,dfnew.shape[0]):
        if dfnew.BusPC[i] >= 0.00357:
            dfnew.BusPCV[i] = 1
        elif dfnew.BusPC[i] >= 0.00269:
            dfnew.BusPCV[i] = 0.75
        elif dfnew.BusPC[i] >= 0.00188:
            dfnew.BusPCV[i] = 0.5
        
    dfnew['MaxC'] = 0.25
    for i in range(0,dfnew.shape[0]):
        if dfnew.MaxTInc[i] > 5:
            dfnew.MaxC[i] = 1
        elif dfnew.MaxTInc[i] > 0:
            dfnew.MaxC[i] = 0.75
        elif dfnew.MaxTInc[i] > -5:
            dfnew.MaxC[i] = 0.5
    
    return(dfnew)

#####################
# Making a Graph
#####################

#Function to make a graph from the dataframe
def MakeGraph(dfnew, VarName, year, *density):
    a = dfnew[dfnew.Year == year]  #subset the dataset to a year   
    A = nx.Graph() #set up an empty graph
    A.add_nodes_from(list(a.Name)) #add nodes for each state
    if density: #if the density variable is assigned, account for all of the edges
        temp = EdgeCreate(a, VarName, density)        
    else: #if not then just create one edge between a state and its group, this is only used for graphing, to make it looklighter
        temp = EdgeCreate(a, VarName)    
    #add edges for each of the variables of interest        
    A.add_weighted_edges_from(temp, color='m')
    return(A) #return the graph

def MakeGraphVar(dfnew,year):
    a = dfnew[dfnew.Year == year]  #subset the dataset to a year   
    A = nx.Graph() #set up an empty graph
    A.add_nodes_from(list(a.Name)) #add nodes for each state    
    #set up lists of edge tuples with weights
    temp = HighWeight(a, 'CarPCV')
    temp1 = HighWeight(a, 'BusPCV')
    temp2 = HighWeight(a, 'TruckPCV')
    temp3 = HighWeight(a, 'MaxC')
    #add edges for each of the variables of interest        
    A.add_weighted_edges_from(temp, color='m')
    A.add_weighted_edges_from(temp1, color='b')
    A.add_weighted_edges_from(temp2, color='c')
    A.add_weighted_edges_from(temp3, color='g')    
    return(A) #return the graph    

def GraphYear(A):
    #Color edges of the graph according to variable that connects them    
    edges = A.edges()
    colors = [A[u][v]['color'] for u,v in edges]
       
    #Define regions of the US
    NE = ['Connecticut', 'Delaware', 'Maine', 'Massachusetts', 
          'Maryland', 'New Hampshire', 'New Jersey', 'New York', 'Pennsylvania', 
          'Rhode Island', 'Vermont']    
    SE = ['Alabama', 'Florida', 'Georgia', 'Kentucky', 
          'Mississippi', 'North Carolina', 'South Carolina', 'Tennessee', 
          'Virginia', 'West Virginia']
    PS = ['California', 'Arizona', 'Hawaii', 'Utah', 'Nevada']
    NC = ['Iowa', 'Kansas', 'Minnesota', 'Missouri', 
          'Nebraska', 'North Dakota', 'South Dakota']    
    SC = ['Arkansas', 'Louisiana', 'Oklahoma', 'Texas']    
    RM = ['Colorado', 'Idaho', 'Montana', 'Nevada', 'New Mexico']    
    GP = ['Montana', 'North Dakota', 'South Dakota', 'Nebraska', 'Oklahoma']    
    PN = ['Montana', 'California', 'Wyoming', 'Oregon', 'Washington']
    
    #Color nodes according to the region of the US the state is in    
    color_map = []
    for node in A:
        if node in NE:
            color_map.append('blue')
        elif node in SE:
            color_map.append('orange')
        elif node in PS:
            color_map.append('springgreen')
        elif node in NC:
            color_map.append('lightskyblue')
        elif node in SC:
            color_map.append('lightcoral')
        elif node in RM:
            color_map.append('lightpink')
        elif node in GP:
            color_map.append('plum')
        else: color_map.append('forestgreen')    
    nx.draw(A, node_color = color_map, node_size=100, alpha=0.8, edge_color=colors, with_labels = True) 

# Create edge tuples with weights for the graph for a variable
def EdgeCreate(a, VarName, *density):
    temp = [] #set empty list of tuples
    listst = [] #set empty list of states
    for i in set(a.Name): #looping through the states
        for j in set(a.Name): #looping through the states
            if i != j and i not in listst and j not in listst: #each state cannot be connect with itslef or more than one state for ease of representation of the graph
                if a[VarName][a.Name == i].item()  == a[VarName][a.Name == j].item() : #if both states are in the same binary group of the variable
                    if not density: 
                        listst.append(i) #add one of the states to the list of states
                    temp.append((i,j,a[VarName][a.Name == i].item())) #append with a tuple of state connections
                        
    return temp

# Create edge tuples with weights using just the highest weight
# for the graph for a variable
def HighWeight(a,VarName):
    b = a[a[VarName] == 1]  #subset the dataset to just the highest weights
    temp = [] #set empty list of tuples
    listst = [] #set empty list of states
    for i in set(b.Name): #looping through the states
        for j in set(b.Name): #looping through the states
            if i != j and i not in listst and j not in listst: #each state cannot be connect with itslef or more than one state for ease of representation of the graph
                if b[VarName][b.Name == i].item()  == b[VarName][b.Name == j].item() : #if both states are in the same binary group of the variable
                    temp.append((i,j,a[VarName][a.Name == i].item())) #append with a tuple of state connections
    return temp

#####################
# Network Metrics
#####################

def GraphMetrics(AFull):    
    print(nx.info(AFull))
    Comp(AFull) 
    ClustMetrics(AFull)
    CentrMetrics(AFull)
    
def Comp(AFull):
    #COMPONENTS
    #number of connected components
    numCC = nx.number_connected_components(AFull)
    print()
    print('Number of connected components:')
    print(numCC)
    #largest connected component
    larCC = max(nx.connected_components(AFull), key=len)
    print()
    print('The largest connected components:')
    print(len(larCC))
 
def ClustMetrics(AFull):
    #CLUSTERING
    #clustering coefficient
    tr = len(nx.triangles(AFull)) #number of triangles
    print()
    print('Number of triangles:')
    print(tr/3)
    cln = nx.clustering(AFull) #clustering coefficient for each node
    print()
    print('Clustering coefficient for each node:')
    #print(cln)    
    avgcl = nx.average_clustering(AFull) #average cluseting for the entire graph
    print()
    print('Average clustering coefficient:')
    print(avgcl)
    edcon = nx.edge_connectivity(AFull) #number of edges to disconnect the graph
    print()
    print('Min number of edges to disconect the graph:')
    print(edcon)
    
    #DENSITY
    density = nx.density(AFull)
    print()
    print('Graph density:')
    print(density)

def CentrMetrics(AFull):   
    #CENTRALITY
    cen = nx.degree_centrality(AFull) #centrality degree for each node
    print()
    print('Centrality degree for each node:')
    print(cen)
    c1 = 0
    bet = AFull.nodes
    for i in cen:
        c1 += cen[i]
    AvgCen = c1/len(cen) #average centrality degree 
    print()
    print('Average centrality degree:')
    print(AvgCen)
    
    bet = nx.betweenness_centrality(AFull) #betweenness score for each node
    print()
    print('Betweenness score for each node:')
    print(bet)
    b1 = 0
    for i in bet:
        b1 += bet[i]
    AvgBet = b1/len(bet) #average betweenness score
    print()
    print('Average betweenness score:')
    print(AvgBet)
      
#####################
# Clustering
#####################    

def ModCluster(AFull):
    #if not running, do this pip install -U python-louvain
    import community    
    import matplotlib.pyplot as plt
    # Cluster using the modularity algorithm
    partition = community.best_partition(AFull)    
    # Print clusters - list of each node with the cluster you are in
    print()
    print("Clusters:")
    print(partition)
    # Determine the final modularity value of the network
    modValue = community.modularity(partition, AFull)
    print()
    print("modularity: {}".format(modValue))
    # Get the values for the clusters and select the node color based on the cluster value
    values = [partition.get(node) for node in AFull.nodes()]
    # Save the weights of edges separately to use for graphing    
    edges = AFull.edges()
    weights = [AFull[u][v]['weight'] for u,v in edges]
    nx.draw_random(AFull, cmap = plt.get_cmap('jet'), node_size=100, node_color = values, edge_color='gray', width=weights, with_labels = True)        

def BetweenCluster(AFull):    
    #import necessary packages
    from networkx.algorithms import community as cm
    from networkx import edge_betweenness_centrality as betweenness  
    #identify the most central edge based on weight 
    def CentEdge(G):
         centrality = betweenness(G, weight='weight')
         return max(centrality, key=centrality.get)   
    #use the most weighted edge as the definer for clustering 
    #cluster using the girvan newman algorithm
    clust = cm.girvan_newman(AFull, most_valuable_edge=CentEdge)
    a = tuple(sorted(c) for c in next(clust))
    print()
    print("Clusters:")
    print(a) #print the tuple of clusters 
    print('Number of clusters:')
    print(len(a))
    #loop through the clusters and set up a dict of different clusters
    temp = []
    k = 0
    for i in range(len(a)):
        for j in range(len(a[i])):
            temp.append(k)
        k +=1
    #save the weights of edges separately to use for graphing    
    edges = AFull.edges()
    weights = [AFull[u][v]['weight'] for u,v in edges]
    #draw the graph with the clustering
    nx.draw_random(AFull,  node_size=100, node_color = temp, edge_color='gray', width=weights, with_labels = True)

if __name__ == '__main__':
    Main()